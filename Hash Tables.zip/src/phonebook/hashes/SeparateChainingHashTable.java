/*
 * Name: Ritika Munshi
 * UID: 118345048
 */
package phonebook.hashes;

import phonebook.exceptions.UnimplementedMethodException;
import phonebook.utils.KVPair;
import phonebook.utils.KVPairList;
import phonebook.utils.PrimeGenerator;
import phonebook.utils.Probes;

/**<p>{@link SeparateChainingHashTable} is a {@link HashTable} that implements <b>Separate Chaining</b>
 * as its collision resolution strategy, i.e the collision chains are implemented as actual
 * Linked Lists. These Linked Lists are <b>not assumed ordered</b>. It is the easiest and most &quot; natural &quot; way to
 * implement a hash table and is useful for estimating hash function quality. In practice, it would
 * <b>not</b> be the best way to implement a hash table, because of the wasted space for the heads of the lists.
 * Open Addressing methods, like those implemented in {@link LinearProbingHashTable} and {@link QuadraticProbingHashTable}
 * are more desirable in practice, since they use the original space of the table for the collision chains themselves.</p>
 *
 * @author Ritika Munshi
 * @see HashTable
 * @see SeparateChainingHashTable
 * @see LinearProbingHashTable
 * @see OrderedLinearProbingHashTable
 * @see CollisionResolver
 */
public class SeparateChainingHashTable implements HashTable{

    /* ****************************************************************** */
    /* ***** PRIVATE FIELDS / METHODS PROVIDED TO YOU: DO NOT EDIT! ***** */
    /* ****************************************************************** */

    private KVPairList[] table;
    private int count;
    private PrimeGenerator primeGenerator;
    int capacity;

    // We mask the top bit of the default hashCode() to filter away negative values.
    // Have to copy over the implementation from OpenAddressingHashTable; no biggie.
    private int hash(String key){
        return (key.hashCode() & 0x7fffffff) % table.length;
    }

    /* **************************************** */
    /*  IMPLEMENT THE FOLLOWING PUBLIC METHODS:  */
    /* **************************************** */
    /**
     *  Default constructor. Initializes the internal storage with a size equal to the default of {@link PrimeGenerator}.
     */
    public SeparateChainingHashTable(){
        //throw new UnimplementedMethodException(); // ERASE THIS LINE AFTER IMPLEMENTING THIS METHOD!
    	primeGenerator = new PrimeGenerator();
    	this.capacity = primeGenerator.getCurrPrime();
    	this.count = 0;
        table = new KVPairList[capacity];
    }

    @Override
    public Probes put(String key, String value) {
        //throw new UnimplementedMethodException(); // ERASE THIS LINE AFTER IMPLEMENTING THIS METHOD!
    	int probe=0, probcount;
    	Probes p = new Probes(value, probe);
    	
    	if(key == null || value == null) {
    		throw new IllegalArgumentException ("IllegalArgumentException thrown for put method in Linear Probing.");
    	}
    	int hashcode = hash(key);
    	if(table[hashcode] != null) {
    		table[hashcode].addBack(key, value);  	
    		probe++;
    	}   
    	else {
    		table[hashcode] = new KVPairList();
        	table[hashcode].addBack(key, value); 
        	probe++;
    	}    
    	count++;
    	probcount = probe;
    	p = new Probes(value, probcount);
    	return p;
    }//put method ends

    @Override
    public Probes get(String key) {
       // throw new UnimplementedMethodException(); // ERASE THIS LINE AFTER IMPLEMENTING THIS METHOD!
    	int hashcode = hash(key);
    	int probcount=0,pcount;
    	String val = null;
    	String value=null;
    	Probes probe = null;
    	
    	//if key is null
    	if(key == null) {
        	probe = new Probes(null, 0);
        	return probe;
        }     	
    	if(table[hashcode] != null) {    
    		//if key exist
    		if(table[hashcode].containsKey(key) == true) {
    			Probes pro = table[hashcode].getValue(key);
    			probcount = pro.getProbes();
    			value = pro.getValue();
    		}//inner if ends    		
    		//if key does not exist
    		else {
    			Probes pro = table[hashcode].getValue(key);
    			probcount = pro.getProbes();
    			value = pro.getValue();
    		}//else ends
    	}//outer if ends    	
    	pcount = probcount;
    	val = value;
    	probe = new Probes(val, pcount);
    	return probe;
    }//get method ends

    @Override
    public Probes remove(String key) {
       // throw new UnimplementedMethodException(); // ERASE THIS LINE AFTER IMPLEMENTING THIS METHOD!
    	int hashcode = hash(key), probcount=0, pcount;    	
    	Probes p1 = table[hashcode].getValue(key);
    	String value = p1.getValue();    	
    	Probes probe = new Probes(value, probcount);
    	
    	if(key == null) {
	        probe = new Probes (null,0);
	        return probe;
        }
    	if(table[hashcode] != null) {    		
    		if(table[hashcode].containsKey(key) == true) {
    			count--;
    			table[hashcode].removeByKey(key);
    			probcount++;
    		}
    		else {
    			Probes p = table[hashcode].getValue(key);
    			int pro = p.getProbes();
    			probcount = pro;
    		} 
    	}//outer if ends
    	pcount = probcount;
    	probe = new Probes(value, pcount);  
    	return probe;
    }//remove method ends

    @Override
    public boolean containsKey(String key) {
       // throw new UnimplementedMethodException(); // ERASE THIS LINE AFTER IMPLEMENTING THIS METHOD!
    	int hashcode = hash(key);
    	
    	if(table[hashcode].containsKey(key) == true) {
    		return true;
    	}
    	return false;
    }//containsKey method ends

    @Override
    public boolean containsValue(String value) {
       // throw new UnimplementedMethodException(); // ERASE THIS LINE AFTER IMPLEMENTING THIS METHOD!
    	for (int i = 0; i<capacity; i++) {
            if (table[i].getKey(value).equals(value)) {
                return true;
            }
        }
        return false;
    }//containsValue method ends

    @Override
    public int size() {
        //throw new UnimplementedMethodException(); // ERASE THIS LINE AFTER IMPLEMENTING THIS METHOD!
    	return count;
    }//size method ends

    @Override
    public int capacity() {
        return capacity; // Or the value of the current prime.
    }//capacity method ends
    
    //auxiliary function for enlarge and shrink
    public void reinsert(String key, String value, KVPairList[] table) {
        //throw new UnimplementedMethodException(); // ERASE THIS LINE AFTER IMPLEMENTING THIS METHOD!
    	int hashcode = hash(key);
    	
    	if(key == null || value == null) {
    		throw new IllegalArgumentException ("IllegalArgumentException thrown for put method in Linear Probing.");
    	}
    	if(table[hashcode] != null) {
    		table[hashcode].addBack(key, value);  	
    	}   
    	else {
    		table[hashcode] = new KVPairList();
        	table[hashcode].addBack(key, value); 
    	}    	
    }//aux method ends
    
    /**
     * Enlarges this hash table. At the very minimum, this method should increase the <b>capacity</b> of the hash table and ensure
     * that the new size is prime. The class {@link PrimeGenerator} implements the enlargement heuristic that
     * we have talked about in class and can be used as a black box if you wish.
     * @see PrimeGenerator#getNextPrime()
     */
    public void enlarge() {
        //throw new UnimplementedMethodException(); // ERASE THIS LINE AFTER IMPLEMENTING THIS METHOD!
    	int newcap = primeGenerator.getNextPrime();
    	KVPairList newt = new KVPairList();
    	KVPairList[] newtable = new KVPairList[newcap];
        KVPairList[] old_table = table;
        table = newtable;
        int old_cap = this.capacity;
        this.capacity = newcap;
        int hashcode;
    	
    	for(int i = 0; i < old_cap; i++) {
    		newt = old_table[i];
    		if(newt != null) {
    			if(newt.iterator().hasNext() == true) {
        			KVPair kvpair = newt.iterator().next();
        			String k = kvpair.getKey();
        			String v = kvpair.getValue();
        			hashcode = hash(k);
        			reinsert(k,v,table);
        		}//inner if ends
    		}//newt if ends
    	}//for loop ends    
    	
    }//enlarge method ends

    /**
     * Shrinks this hash table. At the very minimum, this method should decrease the size of the hash table and ensure
     * that the new size is prime. The class {@link PrimeGenerator} implements the shrinking heuristic that
     * we have talked about in class and can be used as a black box if you wish.
     *
     * @see PrimeGenerator#getPreviousPrime()
     */
    public void shrink(){
       // throw new UnimplementedMethodException(); // ERASE THIS LINE AFTER IMPLEMENTING THIS METHOD!
    	int newcap = primeGenerator.getPreviousPrime();
    	KVPairList newt = new KVPairList();
    	KVPairList newt1 = new KVPairList();
    	KVPairList[] newtable = new KVPairList[newcap];
        KVPairList[] old_table = table;
        table = newtable;
        int old_cap = this.capacity;
        this.capacity = newcap;
        int hashcode;
        
        for(int i = 0; i < old_cap; i++) {
    		newt = old_table[i];
    		if(newt != null) {
    			if(newt.iterator().hasNext() == true) {
        			KVPair kvpair = newt.iterator().next();
        			String k = kvpair.getKey();
        			String v = kvpair.getValue();
        			hashcode = hash(k);
        			reinsert(k,v,table);
        		}//inner if ends
    		}//newt if ends
    	}//for loop ends   
        
    }//shrink method ends
}
