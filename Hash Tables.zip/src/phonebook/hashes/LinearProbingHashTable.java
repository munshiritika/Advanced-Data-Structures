/*
 * Name: Ritika Munshi
 * UID: 118345048
 */
package phonebook.hashes;

import java.util.Hashtable;
import java.util.Set;

import phonebook.exceptions.UnimplementedMethodException;
import phonebook.utils.KVPair;
import phonebook.utils.PrimeGenerator;
import phonebook.utils.Probes;

/**
 * <p>{@link LinearProbingHashTable} is an Openly Addressed {@link HashTable} implemented with <b>Linear Probing</b> as its
 * collision resolution strategy: every key collision is resolved by moving one address over. It is
 * the most famous collision resolution strategy, praised for its simplicity, theoretical properties
 * and cache locality. It <b>does</b>, however, suffer from the &quot; clustering &quot; problem:
 * collision resolutions tend to cluster collision chains locally, making it hard for new keys to be
 * inserted without collisions. {@link QuadraticProbingHashTable} is a {@link HashTable} that
 * tries to avoid this problem, albeit sacrificing cache locality.</p>
 *
 * @author Ritika Munshi
 *
 * @see HashTable
 * @see SeparateChainingHashTable
 * @see OrderedLinearProbingHashTable
 * @see QuadraticProbingHashTable
 * @see CollisionResolver
 */
public class LinearProbingHashTable extends OpenAddressingHashTable {

    /* ********************************************************************/
    /* ** INSERT ANY PRIVATE METHODS OR FIELDS YOU WANT TO USE HERE: ******/
    /* ********************************************************************/
	int capacity;
	int size;
	int count;
    boolean soft_del;	

    /* ******************************************/
    /*  IMPLEMENT THE FOLLOWING PUBLIC METHODS: */
    /* **************************************** */

    /**
     * Constructor with soft deletion option. Initializes the internal storage with a size equal to the starting value of  {@link PrimeGenerator}.
     *
     * @param soft A boolean indicator of whether we want to use soft deletion or not. {@code true} if and only if
     *             we want soft deletion, {@code false} otherwise.
     */
    public LinearProbingHashTable(boolean soft) {
      //  throw new UnimplementedMethodException(); // ERASE THIS LINE AFTER IMPLEMENTING THIS METHOD!
    	primeGenerator = new PrimeGenerator();
    	this.capacity = primeGenerator.getCurrPrime();
    	this.size = 0;
        this.soft_del = soft;
        table = new KVPair[capacity];
    }//constructor ends
    
    //auxiliary function to compute the hash code of the key
    public int hash_code(String key) {
        return (hash(key)); 							   //hash is the function that is in OpenAddressingHashTable
    }//auxiliary function ends
    
    
    //auxiliary function for put
    public Probes auxiliary_put(String key, String value, KVPair[] table) {
    	int hashcode, probcount=0;
    	
		for(hashcode = hash_code(key); table[hashcode] != null; hashcode = (hashcode + 1) % capacity) {
			probcount++;								   // increase the probe count every time you go for searching
		}
		table[hashcode] = new KVPair(key, value);  		   // store the key and value										  
		probcount++;									   // increase the number of probes
		Probes probe = new Probes(value, probcount);
		return probe;	
    }//auxiliary function auxiliary_put ends
    
  //auxiliary function for put
    public Probes auxiliary(String key, String value) {
    	int hashcode, probcount=0;
    	
		for(hashcode = hash_code(key); table[hashcode] != null; hashcode = (hashcode + 1) % capacity) {
			if ((table[hashcode].getKey()).equals(key)) {  // if the key is found
				probcount++;							   // increase the number of probes
				count++;  								   // increase the size
				table[hashcode].setKey(key);			   // set the key
				table[hashcode].setValue(value);           // set the value
				Probes probe = new Probes(value, probcount);
				return probe;
			}
			probcount++;								   // increase the probe count every time you go for searching
		}
		table[hashcode] = new KVPair(key, value);  		   // store the key and value			
		count++;											   // increase the size
		size++;
		probcount++;									   // increase the number of probes
		Probes probe = new Probes(value, probcount);
		return probe;	
    }//auxiliary function auxiliary_put ends
    
    //auxiliary function for put when not resize
    public int resize(int new_capacity) {
    	int i, count1=0, probe=0, total,probes_auxi;
    	Probes p = null;
        KVPair[] new_table = new KVPair[new_capacity];
        KVPair[] old_table = table;
        table = new_table;
        int old_cap = this.capacity;
        this.capacity = new_capacity;
     
        for (i = 0; i < old_cap; i++) {
        	if(old_table[i] != null && old_table[i] != TOMBSTONE) {
        		 if (old_table[i].getKey() != null) {
        			 count1++; 								//one increment of search of not null        			 
        			 p=auxiliary_put(old_table[i].getKey(),old_table[i].getValue(), table);
        			 probe = p.getProbes(); 
        			 count1 = count1+probe;
                 }//inner if
        		 else {
        			 count1++; 
        		 }//inner else			 
        	}//outer if
        	else {
        		count1++;	
        	}//outer else
        }//for loop
    	total = count1;
    	
    	return total;
    }//auxiliary function resize ends

    
    /**
     * Inserts the pair &lt;key, value&gt; into this. The container should <b>not</b> allow for {@code null}
     * keys and values, and we <b>will</b> test if you are throwing a {@link IllegalArgumentException} from your code
     * if this method is given {@code null} arguments! It is important that we establish that no {@code null} entries
     * can exist in our database because the semantics of {@link #get(String)} and {@link #remove(String)} are that they
     * return {@code null} if, and only if, their key parameter is {@code null}. This method is expected to run in <em>amortized
     * constant time</em>.
     * <p>
     * Instances of {@link LinearProbingHashTable} will follow the writeup's guidelines about how to internally resize
     * the hash table when the capacity exceeds 50&#37;
     *
     * @param key   The record's key.
     * @param value The record's value.
     * @return The {@link phonebook.utils.Probes} with the value added and the number of probes it makes.
     * @throws IllegalArgumentException if either argument is {@code null}.
     */
    @Override
    public Probes put(String key, String value) {
       // throw new UnimplementedMethodException(); // ERASE THIS LINE AFTER IMPLEMENTING THIS METHOD!
    	int probcount=0, num=0, probes_auxi=0, prob=0;;
    	Probes p=null;
    	
    	//throw an exception if either of our argument is null
    	if(key == null || value == null) {
    		throw new IllegalArgumentException ("IllegalArgumentException thrown for put method in Linear Probing.");
    	}
    	//Check if 50% < (number of elements + number of tombstones) / capacity.
    	if(size > capacity/2) { 						   //number of element is 0.5 more than the capacity of our keys and values array
    		num = resize(primeGenerator.getNextPrime());
    		p = auxiliary_put(key, value, table);
    		count++;
    		size++;
    		probes_auxi = p.getProbes();
    	}
    	else {
    		p = auxiliary(key, value);
    		prob = p.getProbes();        	
    	}
    	String val = p.getValue();
    	Probes result = new Probes(val, probes_auxi + num + prob);
		return (result);
    }//put method ends
    
    
    //auxiliary function to search for a given key if that exist
    public boolean check_key(String key, int probes_count) {
    	boolean flag = false;
    	int i;
    	
        for (i = hash_code(key); table[i] != null; i = (i + 1) % capacity) {
        	if (table[i].getKey().equals(key)) {
            	probes_count++;
            	flag = true;
                break;
            }
            probes_count++;
            flag = false;
        }
        probes_count++;
        if(flag = true) {
        	return true;
        }
        return false;
    }//auxiliary function ends for search

    @Override
    public Probes get(String key) {
       // throw new UnimplementedMethodException(); // ERASE THIS LINE AFTER IMPLEMENTING THIS METHOD!
    	String val = null;
    	int probe_count = 0;
    	
        if(key == null) { //if key is null
        	probe_count = 0;
        	val = null;
        	Probes probe = new Probes(val, probe_count);
        	return probe;
        }     
        if(check_key(key, probe_count) == false){  //if the key does not exist
        	val = null;
        	Probes probe = new Probes(val, probe_count);
        	return probe;
        }
        for (int i = hash_code(key); table[i] != null; i = (i + 1) % capacity) {
        	 if (table[i].getKey().equals(key)) {
        		 val = table[i].getValue();
        		 break;
        	 }
        	 probe_count++;
        }
        probe_count++;       
        Probes probe = new Probes(val, probe_count);
        return probe;
    }//get method ends
    
    /**
     * <b>Return</b> the value associated with key in the {@link HashTable}, and <b>remove</b> the {@link phonebook.utils.KVPair} from the table.
     * If key does not exist in the database
     * or if key = {@code null}, this method returns {@code null}. This method is expected to run in <em>amortized constant time</em>.
     *
     * @param key The key to search for.
     * @return The {@link phonebook.utils.Probes} with associated value and the number of probe used. If the key is {@code null}, return value {@code null}
     * and 0 as number of probes; if the key doesn't exist in the database, return {@code null} and the number of probes used.
     */
    @Override
    public Probes remove(String key) {
     //   throw new UnimplementedMethodException(); // ERASE THIS LINE AFTER IMPLEMENTING THIS METHOD!
    	String val = null;
    	Probes probe=get(key);
    	Probes g=null;
    	int hashcode = hash_code(key); 
    	int probcount = 0;
    	
        if(key == null) {
        	probcount = 0;
	        val = null;
	        probe = new Probes(val, probcount);
	        return probe;
        }	    
        for (hashcode = hash_code(key); table[hashcode] != null; hashcode = (hashcode + 1) % capacity) {
            if (table[hashcode].getKey().equals(key)) {
            	break;
            }
            probcount++;
        }
        probcount++;        
        if(table[hashcode] == null) {
        	probe = new Probes(null, probcount);
        	return probe;
        }
        val=table[hashcode].getValue();       
       //if soft deletion set that key and value to TOMBSTONE
       if(soft_del == true) {
    	   table[hashcode] = TOMBSTONE;
    	   count--;
       }    
       // if hard deletion then we do the reinsertion with only the cluster and do rehashing
       if(soft_del == false) { 
    	   table[hashcode] = null;
           hashcode = (hashcode + 1) % capacity;
           while (table[hashcode] != null) {
               String k = table[hashcode].getKey();
               String v = table[hashcode].getValue();
               table[hashcode] = null;
               probcount++;
               size--;
               count--;
               Probes pp = put(k,v);
               int d = pp.getProbes();               
               probcount+=d;
               hashcode = (hashcode + 1) % capacity;
           }//while ends
           probcount++;
           count--;
           size--;
       }//if ends 
       probe = new Probes(val, probcount);       
       return probe;       
    }//remove method ends

    @Override
    public boolean containsKey(String key) {
       // throw new UnimplementedMethodException(); // ERASE THIS LINE AFTER IMPLEMENTING THIS METHOD!
    	boolean flag = false;
        
        int hashcode = hash_code(key);
        for (hashcode = (hashcode + 1) % capacity; table[hashcode] != null; hashcode = (hashcode + 1) % capacity) {
        	 if (table[hashcode].getKey().equals(key)) {
        		 flag = true;
        		 break;
        	 }
        	 else {
        		 flag = false;
        	 }
        }
        return flag;
    }//containsKey method ends

    @Override
    public boolean containsValue(String value) {
       // throw new UnimplementedMethodException(); // ERASE THIS LINE AFTER IMPLEMENTING THIS METHOD!
    	 for (int i = 0; i<capacity; i++) {
             if (table[i].getValue().equals(value)) {
                 return true;
             }
         }
         return false;    	
    }//containsValue method ends

    @Override
    public int size() {
        //throw new UnimplementedMethodException(); // ERASE THIS LINE AFTER IMPLEMENTING THIS METHOD!
    	return count;

    }//size method ends

    @Override
    public int capacity() {
        //throw new UnimplementedMethodException(); // ERASE THIS LINE AFTER IMPLEMENTING THIS METHOD!
    	return capacity;
    }//capacity method ends
}
