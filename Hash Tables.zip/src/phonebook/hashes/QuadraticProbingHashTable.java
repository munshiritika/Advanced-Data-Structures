/*
 * Name: Ritika Munshi
 * UID: 118345048
 */
package phonebook.hashes;

import phonebook.exceptions.UnimplementedMethodException;
import phonebook.utils.KVPair;
import phonebook.utils.PrimeGenerator;
import phonebook.utils.Probes;

/**
 * <p>{@link QuadraticProbingHashTable} is an Openly Addressed {@link HashTable} which uses <b>Quadratic
 * Probing</b> as its collision resolution strategy. Quadratic Probing differs from <b>Linear</b> Probing
 * in that collisions are resolved by taking &quot; jumps &quot; on the hash table, the length of which
 * determined by an increasing polynomial factor. For example, during a key insertion which generates
 * several collisions, the first collision will be resolved by moving 1^2 + 1 = 2 positions over from
 * the originally hashed address (like Linear Probing), the second one will be resolved by moving
 * 2^2 + 2= 6 positions over from our hashed address, the third one by moving 3^2 + 3 = 12 positions over, etc.
 * </p>
 *
 * <p>By using this collision resolution technique, {@link QuadraticProbingHashTable} aims to get rid of the
 * &quot;key clustering &quot; problem that {@link LinearProbingHashTable} suffers from. Leaving more
 * space in between memory probes allows other keys to be inserted without many collisions. The tradeoff
 * is that, in doing so, {@link QuadraticProbingHashTable} sacrifices <em>cache locality</em>.</p>
 *
 * @author Ritika Munshi
 *
 * @see HashTable
 * @see SeparateChainingHashTable
 * @see OrderedLinearProbingHashTable
 * @see LinearProbingHashTable
 * @see CollisionResolver
 */
public class QuadraticProbingHashTable extends OpenAddressingHashTable {

    /* ********************************************************************/
    /* ** INSERT ANY PRIVATE METHODS OR FIELDS YOU WANT TO USE HERE: ******/
    /* ********************************************************************/
	int capacity;
	int size;
    boolean soft_del;
    /* ******************************************/
    /*  IMPLEMENT THE FOLLOWING PUBLIC METHODS: */
    /* **************************************** */

    /**
     * Constructor with soft deletion option. Initializes the internal storage with a size equal to the starting value of  {@link PrimeGenerator}.
     * @param soft A boolean indicator of whether we want to use soft deletion or not. {@code true} if and only if
     *               we want soft deletion, {@code false} otherwise.
     */
    public QuadraticProbingHashTable(boolean soft) {
       // throw new UnimplementedMethodException(); // ERASE THIS LINE AFTER IMPLEMENTING THIS METHOD!
        primeGenerator = new PrimeGenerator();
    	this.capacity = primeGenerator.getCurrPrime();
    	this.size = 0;
        this.soft_del = soft;
        table = new KVPair[capacity];
    }
    
    //auxiliary function to compute the hash code of the key
    public int hash_key(String key) {
    	int val=0;
    	val = (int)(key.hashCode() & 0x7fffffff) ;
        return val;
    }//auxiliary function ends
    
    
    //auxiliary function for put
    public Probes auxiliary_put(String key, String value, KVPair[] table) {
    	int hashcode, probcount=0,i;
    	
		for(i=1,hashcode = (int)((hash_key(key)+(i-1)+Math.pow(i-1, 2))%capacity); table[hashcode] != null; i++,hashcode = (int)((hash_key(key)+(i-1)+Math.pow(i-1, 2))%capacity)) {
			probcount++;								   // increase the probe count every time you go for searching
		}		
		table[hashcode] = new KVPair(key, value);  		   // store the key and value
		probcount++;									   // increase the number of probes
		Probes probe = new Probes(value, probcount);
		return probe;	
    }//auxiliary function auxiliary_put ends
    
  //auxiliary function for put
    public Probes auxiliary(String key, String value) {
    	int i, hashcode, probcount=0;
    	
		for(i=1, hashcode =(int)((hash_key(key)+(i-1)+Math.pow(i-1, 2))%capacity); table[hashcode] != null; i++,hashcode =(int)((hash_key(key)+(i-1)+Math.pow(i-1, 2))%capacity)) {
			if ((table[hashcode].getKey()).equals(key)) {  // if the key is found
				probcount++;							   // increase the number of probes
				size++;  								   // increase the size
				table[hashcode].setKey(key);
				table[hashcode].setValue(value);           // set the value
				Probes probe = new Probes(value, probcount);
				return probe;
			}
			probcount++;								   // increase the probe count every time you go for searching
		}		
		table[hashcode] = new KVPair(key, value);  		   // store the key and value			
		size++;											   // increase the size
		probcount++;									   // increase the number of probes
		Probes probe = new Probes(value, probcount);
		return probe;	
    }//auxiliary function auxiliary_put ends
    
    //auxiliary function for put when not resize
    public int resize(int new_capacity) {
    	int i, count=0, probe=0, total,probes_auxi;
    	Probes p = null;
        KVPair[] new_table = new KVPair[new_capacity];
        KVPair[] old_table = table;
        table = new_table;
        int old_cap = this.capacity;
        this.capacity = new_capacity;
     
        for (i = 0; i < old_cap; i++) {
        	if(old_table[i] != null && old_table[i] != TOMBSTONE) {
        		 if (old_table[i].getKey() != null) {
        			 count++; //one increment of search of not null        			 
        			 p=auxiliary_put(old_table[i].getKey(),old_table[i].getValue(), table);
        			 probe = p.getProbes(); 
        			 count = count+probe;
                 }//inner if
        		 else {
        			 count++; 
        		 }//inner else			 
        	}//outer if
        	else {
        		count++;	
        	}//outer else
        }//for loop
    	total = count;
    	
    	return total;
    }//auxiliary function resize ends

    
    @Override
    public Probes put(String key, String value) {
        //throw new UnimplementedMethodException(); // ERASE THIS LINE AFTER IMPLEMENTING THIS METHOD!
    	int probcount=0, num=0, probes_auxi=0, prob=0;;
    	Probes p=null;
    	KVPair[] new_table = new KVPair[capacity];
    	
    	//throw an exception if either of our argument is null
    	if(key == null || value == null) {
    		throw new IllegalArgumentException ("IllegalArgumentException thrown for put method in Linear Probing.");
    	}
    	//Check if 50% < (number of elements + number of tombstones) / capacity.
    	if(size > capacity/2) { 						   //number of element is 0.5 more than the capacity of our keys and values array
    		num = resize(primeGenerator.getNextPrime());
    		p = auxiliary_put(key, value, table);
    		size++;
    		probes_auxi = p.getProbes();
    	}    	
    	else {
    		p = auxiliary(key, value);
    		prob = p.getProbes();
    	}
    	String val = p.getValue();    	
    	Probes result = new Probes(val, probes_auxi + num + prob); 
		return (result);
    }

    //auxiliary function to search for a given key if that exist
    public boolean check_key(String key, int probes_count) {
    	boolean flag = false;
    	int hashcode,i;
        for (i=1, hashcode =(int)((hash_key(key)+(i-1)+Math.pow(i-1, 2))%capacity); table[hashcode] != null; i++,hashcode =(int)((hash_key(key)+(i-1)+Math.pow(i-1, 2))%capacity)) {
        	if (table[hashcode].getKey().equals(key) || table[hashcode].getKey().equals("")) {
            	probes_count++;
            	flag = true;
                break;
            }
            probes_count++;
            flag = false;
        }
        
        probes_count++;
        if(flag = true) {
        	return true;
        }
        return false;
    }//auxiliary function ends for search
 
    @Override
    public Probes get(String key) {
       // throw new UnimplementedMethodException(); // ERASE THIS LINE AFTER IMPLEMENTING THIS METHOD!
    	String val = null;
    	int probe_count = 0;
    	
        if(key == null) { //if key is null
        	probe_count = 0;
        	val = null;
        	Probes probe = new Probes(val, probe_count);
        	return probe;
        }     
        if(check_key(key, probe_count) == false){  //if the key does not exist
        	val = null;
        	Probes probe = new Probes(val, probe_count);
        	return probe;
        }
        int i,hashcode;
        for (i=1, hashcode =(int)((hash_key(key)+(i-1)+Math.pow(i-1, 2))%capacity); table[hashcode] != null; i++,hashcode =(int)((hash_key(key)+(i-1)+Math.pow(i-1, 2))%capacity)) {
        	 if (table[hashcode].getKey().equals(key)) {
        		 val = table[hashcode].getValue();
        		 break;
        	 }
        	 probe_count++;
        }
        probe_count++;       
        Probes probe = new Probes(val, probe_count);
        return probe;
    }
    
  //auxiliary function for put when not resize
    public int reinsert(String key, String value, KVPair[] newtable) {
    	int i, count=0, probe=0;
    	Probes p = null;
        newtable = new KVPair[capacity];
        KVPair[] old_table = table;
        table = newtable;
       
        for (i = 0; i < capacity; i++) {
        	count++;
        	if(old_table[i] != null) {
        		 if (old_table[i].getKey() != null) { 
        			 p=auxiliary_put(old_table[i].getKey(),old_table[i].getValue(), table);
        			 probe = p.getProbes(); 
        			 count = count+probe;
                 }//inner if ends
        	}//outer if ends
        }//for loop ends  	
    	return count;
    }//auxiliary function resize ends
    
 
    @Override
    public Probes remove(String key) {
        //throw new UnimplementedMethodException(); // ERASE THIS LINE AFTER IMPLEMENTING THIS METHOD!
    	String val = null;
    	int probcount = 0, re=0;
    	 int j=2;
         int i=1;
    	Probes probe=get(key);
    	Probes g=null;
    	
        if(key == null) {
        	probcount = 0;
	        val = null;
	        probe = new Probes(val, probcount);
	        return probe;
        }       
        int hashcode =(int)((hash_key(key)+(i-1)+Math.pow(i-1, 2))%capacity);  
        for (i=1,hashcode =(int)((hash_key(key)+(i-1)+Math.pow(i-1, 2))%capacity); table[hashcode] != null; i++,hashcode =(int)((hash_key(key)+(i-1)+Math.pow(i-1, 2))%capacity)) {
            if (table[hashcode].getKey().equals(key)) {
            	break;
            }
            probcount++;
        }
        probcount++;
        if(table[hashcode] == null) {
        	probe = new Probes(null, probcount);
        	return probe;
        }        
        val=table[hashcode].getValue();
       //if soft deletion set that key and value to TOMBSTONE
       if(soft_del == true) {
    	   table[hashcode] = TOMBSTONE;	
    	   count=size;
       } 
       // if hard deletion then we do the re-insertion with only the cluster and do rehashing
       if(soft_del == false) { 
    	   table[hashcode] = null;
           size--;
           int d = resize(capacity);
           probcount += d;
       }
       probe = new Probes(val, probcount);
       return probe;
    }//remove method ends


    @Override
    public boolean containsKey(String key) {
       //throw new UnimplementedMethodException(); // ERASE THIS LINE AFTER IMPLEMENTING THIS METHOD!;
        boolean flag = false;
    
        int i,hashcode;
        for (i=1, hashcode =(int)((hash_key(key)+(i-1)+Math.pow(i-1, 2))%capacity); table[hashcode] != null; i++,hashcode =(int)((hash_key(key)+(i-1)+Math.pow(i-1, 2))%capacity)) {
        	 if (table[hashcode].getKey().equals(key)) {
        		 flag = true;
        		 break;
        	 }
        	 else {
        		 flag = false;
        	 }
        }
        return flag;
    }

    @Override
    public boolean containsValue(String value) {
        //throw new UnimplementedMethodException(); // ERASE THIS LINE AFTER IMPLEMENTING THIS METHOD!
    	for (int i = 0; i<capacity; i++) {
            if (table[i].getValue().equals(value)) {
                return true;
            }
        }
        return false;
    }
    @Override
    public int size(){
       // throw new UnimplementedMethodException(); // ERASE THIS LINE AFTER IMPLEMENTING THIS METHOD!
    	return size;
    }

    @Override
    public int capacity() {
        //throw new UnimplementedMethodException(); // ERASE THIS LINE AFTER IMPLEMENTING THIS METHOD!
    	return capacity;
    }

}