/*Name: Ritika Munshi
 * UID: 118345048
 */
package spatial.nodes;

import spatial.exceptions.UnimplementedMethodException;
import spatial.kdpoint.KDPoint;
import spatial.knnutils.BoundedPriorityQueue;
import spatial.knnutils.NNData;
import spatial.trees.PRQuadTree;

import java.util.ArrayList;
import java.util.Collection;


/** <p>A {@link PRQuadBlackNode} is a &quot;black&quot; {@link PRQuadNode}. It maintains the following
 * invariants: </p>
 * <ul>
 *  <li>It does <b>not</b> have children.</li>
 *  <li><b>Once created</b>, it will contain at least one {@link KDPoint}. </li>
 * </ul>
 *
 * <p><b>YOU ***** MUST ***** IMPLEMENT THIS CLASS!</b></p>
 *
 * @author --- YOUR NAME HERE! ---
 */
public class PRQuadBlackNode extends PRQuadNode {


    /**
     * The default bucket size for all of our black nodes will be 1, and this is something
     * that the interface also communicates to consumers.
     */
    public static final int DEFAULT_BUCKETSIZE = 1;

    /* ******************************************************************** */
    /* *************  PLACE ANY  PRIVATE FIELDS AND METHODS HERE: ************ */
    /* ********************************************************************** */
    
    KDPoint centroid;
    KDPoint p;
	int k;
	int bucketingParam;
	int height;
	//ArrayList that holds the points that we are inserting in our PR-Quad Trees
	ArrayList<KDPoint> points;
	

    /* *********************************************************************** */
    /* ***************  IMPLEMENT THE FOLLOWING PUBLIC METHODS:  ************ */
    /* *********************************************************************** */


    /**
     * Creates a {@link PRQuadBlackNode} with the provided parameters.
     * @param centroid The {@link KDPoint} which will act as the centroid of the quadrant spanned by the current {@link PRQuadBlackNode}.
     * @param k An integer to which 2 is raised to define the side length of the quadrant spanned by the current {@link PRQuadBlackNode}.
     *          See {@link PRQuadTree#PRQuadTree(int, int)} for a full explanation of how k works.
     * @param bucketingParam The bucketing parameter provided to us {@link PRQuadTree}.
     * @see PRQuadTree#PRQuadTree(int, int)
     * @see #PRQuadBlackNode(KDPoint, int, int, KDPoint)
     */
    public PRQuadBlackNode(KDPoint centroid, int k, int bucketingParam){
        super(centroid, k, bucketingParam); // Call to the super class' protected constructor to properly initialize the object is necessary, even for a constructor that just throws!
        //throw new UnimplementedMethodException(); // ERASE THIS LINE AFTER YOU IMPLEMENT THIS METHOD!
        this.centroid = centroid;
        this.k = k;
        this.bucketingParam = bucketingParam;
        this.height = 0;
        points = new ArrayList<KDPoint>();
    }//constructor method ends

    /**
     * Creates a {@link PRQuadBlackNode} with the provided parameters.
     * @param centroid The centroid of the quadrant spanned by the current {@link PRQuadBlackNode}.
     * @param k The exponent to which 2 is raised in order to define the side of the current quadrant. Refer to {@link PRQuadTree#PRQuadTree(int, int)} for
     *          a thorough explanation of this parameter.
     * @param bucketingParam The bucketing parameter of the {@link PRQuadBlackNode}, passed to us by the {@link PRQuadTree} or {@link PRQuadGrayNode} during
     *                       object construction.
     * @param p The {@link KDPoint} with which we want to initialize this.
     * @see #DEFAULT_BUCKETSIZE
     * @see PRQuadTree#PRQuadTree(int, int)
     * @see #PRQuadBlackNode(KDPoint, int, int)
     */
    public PRQuadBlackNode(KDPoint centroid, int k, int bucketingParam, KDPoint p){
        this(centroid, k, bucketingParam); // Call to the current class' other constructor, which takes care of the base class' initialization itself.
        //throw new UnimplementedMethodException(); // ERASE THIS LINE AFTER YOU IMPLEMENT THIS METHOD!
        this.points.add(p);
        this.centroid = centroid;
        this.k = k;
        this.bucketingParam = bucketingParam;
        this.height = 0;
    }//constructor method ends


    /**
     * <p>Inserting a {@link KDPoint} into a {@link PRQuadBlackNode} can have one of two outcomes:</p>
     *
     * <ol>
     *     <li>If, after the insertion, the node's capacity is still <b>SMALLER THAN OR EQUAL TO </b> the bucketing parameter,
     *     we should simply store the {@link KDPoint} internally.</li>
     *
     *     <li>If, after the insertion, the node's capacity <b>SURPASSES</b> the bucketing parameter, we will have to
     *     <b>SPLIT</b> the current {@link PRQuadBlackNode} into a {@link PRQuadGrayNode} which will recursively insert
     *     all the available{@link KDPoint}s. This pprocess will continue until we reach a {@link PRQuadGrayNode}
     *     which successfully separates all the {@link KDPoint}s of the quadrant it represents. Programmatically speaking,
     *     this means that the method will polymorphically call itself, splitting black nodes into gray nodes as long as
     *     is required for there to be a set of 4 quadrants that separate the points between them. This is one of the major
     *     bottlenecks in PR-QuadTrees; the presence of a pair of {@link KDPoint}s with a very small {@link
     *     KDPoint#euclideanDistance(KDPoint) euclideanDistance} between them can negatively impact search in certain subplanes, because
     *     the subtrees through which those subplanes will be modeled will be &quot;unnecessarily&quot; tall.</li>
     * </ol>
     *
     * @param p A {@link KDPoint} to insert into the subtree rooted at the current node.
     * @param k The side length of the quadrant spanned by the <b>current</b> {@link PRQuadGrayNode}. It will need to be updated
     *           per recursive call to help guide the input {@link KDPoint} to the appropriate subtree.
     * @return The subtree rooted at the current node, potentially adjusted after insertion.
     */
    @Override
    public PRQuadNode insert(KDPoint p, int k) {
        //throw new UnimplementedMethodException(); // ERASE THIS LINE AFTER YOU IMPLEMENT THIS METHOD!
    	int num_elements_added = points.size();
    	
    	//if we have not exceeded the bucket size; keep inserting
    	if((num_elements_added+1) <= bucketingParam) {   			
	    	points.add(p); //add the points to your arraylist
	    	return this;   //return whatever you have which is this
    	}//if ends
    	
    	//As soon as bucket size is reached; make the node that has exceeded the limit a gray node--split case
    	else {
    		//else we create a gray node
    		PRQuadGrayNode graynode = new PRQuadGrayNode(centroid, k, bucketingParam);
    		//we loop over all the elements we have inserted into our arraylist and add them to our gray node that we created
    		for (int i = 0; i < points.size(); i++) {
    			graynode.insert(points.get(i), k);
    		}//for loop ends
    		graynode.insert(p, k);
    		return graynode;
    	}//else ends
    	
    }//insert method ends


    /**
     * <p><b>Successfully</b> deleting a {@link KDPoint} from a {@link PRQuadBlackNode} always decrements its capacity by 1. If, after
     * deletion, the capacity is at least 1, then no further changes need to be made to the node. Otherwise, it can
     * be scrapped and turned into a white node.</p>
     *
     * <p>If the provided {@link KDPoint} is <b>not</b> contained by this, no changes should be made to the internal
     * structure of this, which should be returned as is.</p>
     * @param p The {@link KDPoint} to delete from this.
     * @return Either this or null, depending on whether the node underflows.
     */
    @Override
    public PRQuadNode delete(KDPoint p) {
        //throw new UnimplementedMethodException(); // ERASE THIS LINE AFTER YOU IMPLEMENT THIS METHOD!
    	//if the point we want to delete is found then remove it else return this which is as it is
    	if (search(p) == true) {
    		this.points.remove(p);
    		//if after deletion the capacity is less than 1 meaning nothing left then we return null in the sense white node
    		if(this.points.size() == 0) {
    			return null;
    		}//if ends
    	}//if ends
    	
    	return this;
    }//delete method ends

    @Override
    public boolean search(KDPoint p){
       // throw new UnimplementedMethodException(); // ERASE THIS LINE AFTER YOU IMPLEMENT THIS METHOD!
    	boolean flag = false;
    	
    	//if arraylist contains that kdpoint means it does exist in the tree and return true else does not exist so return false
    	if(this.points.contains(p) == true) {
    		flag = true;
    	}//if ends
    	else {
    		flag = false;
    	}//else ends
    		
    	return flag;
    }//search method ends

    @Override
    public int height(){
      //  throw new UnimplementedMethodException(); // ERASE THIS LINE AFTER YOU IMPLEMENT THIS METHOD!
    	return height;
    }//height method ends

    @Override
    public int count()  {
       // throw new UnimplementedMethodException(); // ERASE THIS LINE AFTER YOU IMPLEMENT THIS METHOD!
    	int count = this.points.size();
    	return count;
    }//count method ends

    /** Returns all the {@link KDPoint}s contained by the {@link PRQuadBlackNode}. <b>INVARIANT</b>: the returned
     * {@link Collection}'s size can only be between 1 and bucket-size inclusive.
     *
     * @return A {@link Collection} that contains all the {@link KDPoint}s that are contained by the node. It is
     * guaranteed, by the invariants, that the {@link Collection} will not be empty, and it will also <b>not</b> be
     * a null reference.
     */
    public Collection<KDPoint> getPoints()  {
        //throw new UnimplementedMethodException(); // ERASE THIS LINE AFTER YOU IMPLEMENT THIS METHOD!
    	ArrayList<KDPoint> kdpoints = points;
    	return kdpoints;
    }//getPoints method ends

    @Override
    public void range(KDPoint anchor, Collection<KDPoint> results, double range) {
       // throw new UnimplementedMethodException(); // ERASE THIS LINE AFTER YOU IMPLEMENT THIS METHOD!
    	int i = 0;
    	double distance = 0.0;
    	//loop over all the elements from our arraylist and compute the distance
    	for (i = 0; i < points.size(); i++) {
			distance = (points.get(i)).euclideanDistance(anchor);
			//if the distance computed is less than or equal to the range we add our results or else ignore and move on
			if(distance <= range) {
				results.add(points.get(i));
			}//if ends
		}//for loop ends
    }//range method ends

    @Override
    public NNData<KDPoint> nearestNeighbor(KDPoint anchor, NNData<KDPoint> n) {
        //throw new UnimplementedMethodException(); // ERASE THIS LINE AFTER YOU IMPLEMENT THIS METHOD!
    	int i = 0;
    	double distance = 0.0;
    	//loop over all the points we have in our arraylist
    	for (i = 0; i < points.size(); i++) {
    		KDPoint kdpoint = new KDPoint(points.get(i));
    		//compute the distance
			distance = kdpoint.euclideanDistance(anchor);
			//check if it matches to our situations of updating our n and update respectively
			//first step when nothing is in our n
	    	if(n.getBestGuess() == null && n.getBestDist() == -1.0 && !kdpoint.equals(anchor)) {
	    		n.update(kdpoint, distance);
	    	}//if ends	    	
	    	if(distance < n.getBestDist() && !kdpoint.equals(anchor)) {
	    		n.update(kdpoint, distance);
	    	}//if ends
		}//for loop ends
    	
    	return n;
    }//nearestNeighbor method ends

    @Override
    public void kNearestNeighbors(int k, KDPoint anchor, BoundedPriorityQueue<KDPoint> queue){
        //throw new UnimplementedMethodException(); // ERASE THIS LINE AFTER YOU IMPLEMENT THIS METHOD!
    	//queue = new BoundedPriorityQueue<>(k);
    	int i = 0;
    	double distance = 0.0;  	
    	//loop over all the points we have in our arraylist
    	for (i = 0; i < points.size(); i++) {
    		KDPoint kdpoint = new KDPoint(points.get(i));
    		//compute the distance
			distance = (points.get(i)).euclideanDistance(anchor);
			//if the distance is greater than 0 then only we want to insert into our queue and comes undo KNN
			if(distance > 0.0) {
				queue.enqueue(kdpoint, distance);
			}
		}//for loop ends
    	
    }//kNearestNeighbors method ends
}
