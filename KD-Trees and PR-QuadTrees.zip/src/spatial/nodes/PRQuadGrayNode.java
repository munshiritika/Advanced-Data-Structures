/*Name: Ritika Munshi
 * UID: 118345048
 */
package spatial.nodes;

import spatial.exceptions.UnimplementedMethodException;
import spatial.kdpoint.KDPoint;
import spatial.knnutils.BoundedPriorityQueue;
import spatial.knnutils.NNData;
import spatial.trees.CentroidAccuracyException;
import spatial.trees.PRQuadTree;

import java.util.ArrayList;
import java.util.Collection;

/** <p>A {@link PRQuadGrayNode} is a gray (&quot;mixed&quot;) {@link PRQuadNode}. It
 * maintains the following invariants: </p>
 * <ul>
 *      <li>Its children pointer buffer is non-null and has a length of 4.</li>
 *      <li>If there is at least one black node child, the total number of {@link KDPoint}s stored
 *      by <b>all</b> of the children is greater than the bucketing parameter (because if it is equal to it
 *      or smaller, we can prune the node.</li>
 * </ul>
 *
 * <p><b>YOU ***** MUST ***** IMPLEMENT THIS CLASS!</b></p>
 *
 *  @author --- YOUR NAME HERE! ---
 */
public class PRQuadGrayNode extends PRQuadNode{


    /* ******************************************************************** */
    /* *************  PLACE ANY  PRIVATE FIELDS AND METHODS HERE: ************ */
    /* ********************************************************************** */
	
	//KDPoint centroid;
  //  KDPoint p;
	int k;
	int bucketingParam;
	int height;
	int count;
	//ArrayList that holds the points that we are inserting
	ArrayList<KDPoint> points; //have all the points in our arraylist
	PRQuadNode[] quadrants; //4 quadrants which are 4 children for each node
	

    /* *********************************************************************** */
    /* ***************  IMPLEMENT THE FOLLOWING PUBLIC METHODS:  ************ */
    /* *********************************************************************** */

    /**
     * Creates a {@link PRQuadGrayNode}  with the provided {@link KDPoint} as a centroid;
     * @param centroid A {@link KDPoint} that will act as the centroid of the space spanned by the current
     *                 node.
     * @param k The See {@link PRQuadTree#PRQuadTree(int, int)} for more information on how this parameter works.
     * @param bucketingParam The bucketing parameter fed to this by {@link PRQuadTree}.
     * @see PRQuadTree#PRQuadTree(int, int)
     */
    public PRQuadGrayNode(KDPoint centroid, int k, int bucketingParam){
        super(centroid, k, bucketingParam); // Call to the super class' protected constructor to properly initialize the object!
       // throw new UnimplementedMethodException(); // ERASE THIS LINE AFTER YOU IMPLEMENT THIS METHOD!
       // this.centroid = centroid;
        this.k = k;
        this.bucketingParam = bucketingParam;
        this.height = 1;
        this.count = 0; 
        this.quadrants = new PRQuadNode[4];
        points = new ArrayList<KDPoint>();
    }//constructor method ends
    
    //auxiliary function to know the quadrant our point has to be  for delete, insert and search
    public int sector(KDPoint p) {
    	 int edge_dimension = (int) Math.pow(2, k-1);
         int x_point = p.coords[0], y_point = p.coords[1];
         int x_centroid = this.centroid.coords[0], y_centroid = this.centroid.coords[1];
         int x1 = x_centroid - edge_dimension, x2 = x_centroid + edge_dimension;
         int y1 = y_centroid + edge_dimension, y2 = y_centroid - edge_dimension;
         
         //North West: First Quadrant
         if((x_point >= (x1) && x_point < x_centroid) && (y_point <= (y1) && y_point >= y_centroid)) {
        	return 0; 
         }
         //North East: Second Quadrant
         else if((x_point <= (x2) && x_point >= x_centroid) && (y_point <= (y1) && y_point >= y_centroid)) {
        	 return 1;
         }
         //South West: Third Quadrant
         else if((x_point >= (x1) && x_point < x_centroid) && (y_point >= (y2) && y_point < y_centroid)) {
        	 return 2;
         }
         //South East: Fourth Quadrant
         else if((x_point <= (x2) && x_point >= x_centroid) && (y_point >= (y2) && y_point < y_centroid)) {
        	 return 3;
         }
         //Does not exist so we throw an exception
         else {
        	 throw new CentroidAccuracyException("throw Centroid Accuracy Exception for sector");
         }         
    }//sector method ends

    //auxiliary function for insertion
    public PRQuadNode insert_aux(PRQuadGrayNode node, KDPoint p, int k, int x_point, int y_point, int x_centroid, int y_centroid, int edge_dimension) {   
    	int sec = sector(p);
    	
    	//-,+ : First Quadrant : North-West
    	if(sec == 0) {
        	//if it is already a black node meaning has elements less than bucket parameter then we do a recursive insertion
        	if(node.quadrants[0] != null) {
        		k = k-1;
        		node.quadrants[0] = node.quadrants[0].insert(p, k);
        	}//if ends
        	//if it is a white node, then we compute the centroid values and make that a black node
        	else {
        		//get the splitting centroid
        		int split_centroid = (int) Math.pow(2, k-2);
        		//we get our new centroid
        		int a = x_centroid - split_centroid;
        		int b = y_centroid + split_centroid;
        		KDPoint new_centroid = new KDPoint(a, b);
        		//update our respective quadrant or the node
        		k = k-1;
        		node.quadrants[0] = new PRQuadBlackNode(new_centroid, k, bucketingParam, p);
        	}//else ends 
        	//update the height of our tree
        	this.height = (Math.max(firstheight_NW(quadrants), Math.max(secondheight_NE(quadrants), Math.max(thirdheight_SW(quadrants), fourthheight_SE(quadrants)))) + 1);
        	//increment the count which hold number of elements we have
        	this.count++;
        	return node;
        }//if ends
    	
        
        //-,- : Third Quadrant : South-West
    	else if(sec == 2) {
        	//if it is already a black node meaning has elements less than bucket parameter then we do a recursive insertion
        	if(node.quadrants[2] != null) {
        		k = k-1;
        		node.quadrants[2] = node.quadrants[2].insert(p, k);
        	}//if ends
        	//if it is a white node, then we compute the centroid values and make that a black node
        	else {
        		//get the splitting centroid
        		int split_centroid = (int) Math.pow(2, k-2);
        		//we get our new centroid
        		int a = x_centroid - split_centroid;
        		int b = y_centroid - split_centroid;
        		KDPoint new_centroid = new KDPoint(a, b);
        		//update our respective quadrant or the node
        		k = k-1;
        		node.quadrants[2] = new PRQuadBlackNode(new_centroid, k, bucketingParam, p);
        	}//else ends
        	//update the height of our tree
        	this.height = (Math.max(firstheight_NW(quadrants), Math.max(secondheight_NE(quadrants), Math.max(thirdheight_SW(quadrants), fourthheight_SE(quadrants)))) + 1); 
        	//increment the count which hold number of elements we have
        	this.count++;
        	return node;
        }//else if ends
        
        //+,+ : Second Quadrant : North-East
    	else if(sec == 1) {
        	//if it is already a black node meaning has elements less than bucket parameter then we do a recursive insertion
        	if(node.quadrants[1] != null) {
        		k = k-1;
        		node.quadrants[1] = node.quadrants[1].insert(p, k);
        	}//if ends
        	//if it is a white node, then we compute the centroid values and make that a black node
        	else {
        		//get the splitting centroid
        		int split_centroid = (int) Math.pow(2, k-2);
        		//we get our new centroid
        		int a = x_centroid + split_centroid;
        		int b = y_centroid + split_centroid;
        		KDPoint new_centroid = new KDPoint(a, b);
        		//update our respective quadrant or the node
        		k = k-1;
        		node.quadrants[1] = new PRQuadBlackNode(new_centroid, k, bucketingParam, p);
        	}//else ends
        	//update the height of our tree
        	this.height = (Math.max(firstheight_NW(quadrants), Math.max(secondheight_NE(quadrants), Math.max(thirdheight_SW(quadrants), fourthheight_SE(quadrants)))) + 1); 
        	//increment the count which hold number of elements we have
        	this.count++;
        	return node;
        }//else if ends

        
        //+,- : Fourth Quadrant : South-East
    	else if(sec == 3) {
        	//if it is already a black node meaning has elements less than bucket parameter then we do a recursive insertion
        	if(node.quadrants[3] != null) {
        		k=k-1;
        		node.quadrants[3] = node.quadrants[3].insert(p, k);
        	}//if ends
        	//if it is a white node, then we compute the centroid values and make that a black node
        	else {
        		//get the splitting centroid
        		int split_centroid = (int) Math.pow(2, k-2);
        		//we get our new centroid
        		int a = x_centroid + split_centroid;
        		int b = y_centroid - split_centroid;
        		KDPoint new_centroid = new KDPoint(a, b);
        		//update our respective quadrant or the node
        		k=k-1;
        		node.quadrants[3] = new PRQuadBlackNode(new_centroid, k, bucketingParam, p);
        		//this.height++;
        	}//else ends 
        	//update the height of our tree
        	this.height = (Math.max(firstheight_NW(quadrants), Math.max(secondheight_NE(quadrants), Math.max(thirdheight_SW(quadrants), fourthheight_SE(quadrants)))) + 1);
        	//increment the count which hold number of elements we have
        	this.count++;
        	return node;
        }//else if ends
        
        else {
        	throw new CentroidAccuracyException("throw Centroid Accuracy Exception for insert");
        }//else ends 	
      
    }//insert_aux method ends

    /**
     * <p>Insertion into a {@link PRQuadGrayNode} consists of navigating to the appropriate child
     * and recursively inserting elements into it. If the child is a white node, memory should be allocated for a
     * {@link PRQuadBlackNode} which will contain the provided {@link KDPoint} If it's a {@link PRQuadBlackNode},
     * refer to {@link PRQuadBlackNode#insert(KDPoint, int)} for details on how the insertion is performed. If it's a {@link PRQuadGrayNode},
     * the current method would be called recursively. Polymorphism will allow for the appropriate insert to be called
     * based on the child object's runtime object.</p>
     * @param p A {@link KDPoint} to insert into the subtree rooted at the current {@link PRQuadGrayNode}.
     * @param k The side length of the quadrant spanned by the <b>current</b> {@link PRQuadGrayNode}. It will need to be updated
     *          per recursive call to help guide the input {@link KDPoint}  to the appropriate subtree.
     * @return The subtree rooted at the current node, potentially adjusted after insertion.
     * @see PRQuadBlackNode#insert(KDPoint, int)
     */
    //white node and make black node; black node might return gray node
    @Override
    public PRQuadNode insert(KDPoint p, int k) {
        //throw new UnimplementedMethodException(); // ERASE THIS LINE AFTER YOU IMPLEMENT THIS METHOD!
    	//we have to encounter for all four quadrants which is +-, ++, --, -+
        int edge_dimension = (int) Math.pow(2, k-1);
        int x_point = p.coords[0], y_point = p.coords[1];
        int x_centroid = this.centroid.coords[0], y_centroid = this.centroid.coords[1];     
        
        PRQuadNode result = insert_aux(this, p, k, x_point, y_point, x_centroid, y_centroid, edge_dimension);
        
        return result;        
    }//insert method ends 

   
    /**
     * <p>Deleting a {@link KDPoint} from a {@link PRQuadGrayNode} consists of recursing to the appropriate
     * {@link PRQuadBlackNode} child to find the provided {@link KDPoint}. If no such child exists, the search has
     * <b>necessarily failed</b>; <b>no changes should then be made to the subtree rooted at the current node!</b></p>
     *
     * <p>Polymorphism will allow for the recursive call to be made into the appropriate delete method.
     * Importantly, after the recursive deletion call, it needs to be determined if the current {@link PRQuadGrayNode}
     * needs to be collapsed into a {@link PRQuadBlackNode}. This can only happen if it has no gray children, and one of the
     * following two conditions are satisfied:</p>
     *
     * <ol>
     *     <li>The deletion left it with a single black child. Then, there is no reason to further subdivide the quadrant,
     *     and we can replace this with a {@link PRQuadBlackNode} that contains the {@link KDPoint}s that the single
     *     black child contains.</li>
     *     <li>After the deletion, the <b>total</b> number of {@link KDPoint}s contained by <b>all</b> the black children
     *     is <b>equal to or smaller than</b> the bucketing parameter. We can then similarly replace this with a
     *     {@link PRQuadBlackNode} over the {@link KDPoint}s contained by the black children.</li>
     *  </ol>
     *
     * @param p A {@link KDPoint} to delete from the tree rooted at the current node.
     * @return The subtree rooted at the current node, potentially adjusted after deletion.
     */
    
    //auxiliary function for deletion for merging case
    public ArrayList<KDPoint> gray_delete(){
    	PRQuadNode[] quad = this.quadrants;    	
    	ArrayList<KDPoint> array = new ArrayList<KDPoint>();    	
    	
    	for (int i = 0; i < quad.length; i++) {
    		if(quad[i] != null) {
    			if(quad[i] instanceof PRQuadBlackNode) {
    				PRQuadBlackNode node = (PRQuadBlackNode) quad[i];
    				array.addAll(node.getPoints());
    			}//if ends
    			else {
    				array.addAll(((PRQuadGrayNode) quad[i]).gray_delete());
    			}//else ends
    		}//if ends
    	}//for loop ends
    	
    	return array;
    }//gray_delete method ends
    
   
    
    @Override
    public PRQuadNode delete(KDPoint p) {
        //throw new UnimplementedMethodException(); // ERASE THIS LINE AFTER YOU IMPLEMENT THIS METHOD! 
         ArrayList<KDPoint> array = new ArrayList<KDPoint>();
         int sec = sector(p);
                 
         //-,+ : First Quadrant : North-West
         if(sec == 0) {
        	 //if it is not the white node
         	if(this.quadrants[0] != null) {
         		//we first recursively call delete
         		this.quadrants[0] = this.quadrants[0].delete(p);
         		//decrement our count
         		this.count--;
         		//if our number of elements is less than the bucket parameter then we come into merging phase
         		if(count > bucketingParam) {
         			//compute the height because we are still more than our bucket parameter
         			this.height = (Math.max(firstheight_NW(quadrants), Math.max(secondheight_NE(quadrants), Math.max(thirdheight_SW(quadrants), fourthheight_SE(quadrants)))) + 1);
         			return this;
         		}
         		else {         			
         			//create a black node
         			PRQuadBlackNode blacknode = new PRQuadBlackNode(centroid, k, bucketingParam);
         			//calling auxiliary function which does our merging
         			array = this.gray_delete();
         			//adding and merging everything to black node
         			for(KDPoint points : array) {
         				blacknode.insert(points, k);
         			}         			
         			//deleting that element
         			blacknode = (PRQuadBlackNode) blacknode.delete(p);         			         			
         			//decrement the height
         			this.height--;
         			return blacknode;
         		}
         	}
         	//if it is a white node, then we just return as it is because nothing to delete
         	else {
         		return this;
         	}          	
         }//first quadrant ends
         
         //-,- : Third Quadrant : South-West
         else if(sec == 2) {
        	//if it is not the white node
         	if(this.quadrants[2] != null) {
         		//we first recursively call delete
         		this.quadrants[2] = this.quadrants[2].delete(p);
         		//decrement our count
         		this.count--;
         		//if our number of elements is less than the bucket parameter then we come into merging phase
        		if(count > bucketingParam) {
         			this.height = (Math.max(firstheight_NW(quadrants), Math.max(secondheight_NE(quadrants), Math.max(thirdheight_SW(quadrants), fourthheight_SE(quadrants)))) + 1);
         			return this;
         		}
         		else {        			
        			//create a black node
        			PRQuadBlackNode blacknode = new PRQuadBlackNode(centroid, k, bucketingParam);  
        			//calling auxiliary function which does our merging
         			array = this.gray_delete();
         			//adding and merging everything to black node
         			for(KDPoint points : array) {
         				blacknode.insert(points, k);
         			}       
         			//deleting that element
         			blacknode = (PRQuadBlackNode) blacknode.delete(p);   
         			//decrement the height
         			this.height--;
         			return blacknode;
         		}
         	}
         	//if it is a white node, then we just return as it is because nothing to delete
         	else {
         		return this;
         	}         
         }//third quadrant ends
         
         //+,+ : Second Quadrant : North-East
         else if(sec == 1) {
        	//if it is not the white node
         	if(this.quadrants[1] != null) {
         		//we first recursively call delete
         		this.quadrants[1] = this.quadrants[1].delete(p);
         		//decrement our count
         		this.count--;
         		//if our number of elements is less than the bucket parameter then we come into merging phase
         		if(count > bucketingParam) {
         			this.height = (Math.max(firstheight_NW(quadrants), Math.max(secondheight_NE(quadrants), Math.max(thirdheight_SW(quadrants), fourthheight_SE(quadrants)))) + 1);
         			return this;
         		}
         		else {       			
         			//create a black node
         			PRQuadBlackNode blacknode = new PRQuadBlackNode(centroid, k, bucketingParam); 
         			//calling auxiliary function which does our merging
         			array = this.gray_delete();
         			//adding and merging everything to black node
         			for(KDPoint points : array) {
         				blacknode.insert(points, k);
         			}      
         			//deleting that element
         			blacknode = (PRQuadBlackNode) blacknode.delete(p);         			
         			//decrement the height
         			this.height--;
         			return blacknode;
         		}
         	}
         	//if it is a white node, then we just return as it is because nothing to delete
         	else {
         		return this;
         	}         	
         }//second quadrant ends
         
         //+,- : Fourth Quadrant : South-East
         else if(sec == 3) {
        	//if it is not the white node
        	 if(this.quadrants[3] != null) {
        		//we first recursively call delete
        		this.quadrants[3] = this.quadrants[3].delete(p);
        		//decrement our count
         		this.count--;
         		//if our number of elements is less than the bucket parameter then we come into merging phase
        		if(count > bucketingParam) {
         			this.height = (Math.max(firstheight_NW(quadrants), Math.max(secondheight_NE(quadrants), Math.max(thirdheight_SW(quadrants), fourthheight_SE(quadrants)))) + 1);
         			return this;
         		}//if(count > bucketingParam) ends
         		else {        			
        			//create a black node
        			PRQuadBlackNode blacknode = new PRQuadBlackNode(centroid, k, bucketingParam);  
        			//calling auxiliary function which does our merging
         			array = this.gray_delete();
         			//adding and merging everything to black node
         			for(KDPoint points : array) {
         				blacknode.insert(points, k);
         			}      
         			//deleting that element
         			blacknode = (PRQuadBlackNode) blacknode.delete(p);         			
         			//decrement the height
         			this.height--;
         			return blacknode;
         		}
         	}
         	//if it is a white node, then we just return as it is because nothing to delete
         	else {
         		return this;
         	}          	
         }//fourth quadrant ends
         
         //if none of the quadrants means the point we want to delete does not exist
         else {
         	//throw new CentroidAccuracyException("throw Centroid Accuracy Exception for delete");
        	 return null;
         }//else ends
     
    }//delete method ends 
    
    public boolean search_aux(PRQuadGrayNode node, KDPoint p) {
    	int sec = sector(p);
        boolean flag = false;
 
    	//-,+ : First Quadrant : North-West
        if(sec == 0) {
        	//if it is a black node meaning has elements so we do a recursive search
        	if(node.quadrants[0] != null) {
        		flag = node.quadrants[0].search(p);
        	}//if ends
        	//if it is a white node, then we return false
        	else {
        		flag = false;
        	}//else ends         	
        	return flag;
        }//if ends
        
        //-,- : Third Quadrant : South-West
        else if(sec == 2) {
        	//if it is a black node meaning has elements so we do a recursive search
        	if(node.quadrants[2] != null) {
        		flag = node.quadrants[2].search(p);
        	}//if ends
        	//if it is a white node, then we return false
        	else {
        		flag = false;
        	}//else ends 
        	return flag;
        }//else if ends
        
        //+,+ : Second Quadrant : North-East
        else if(sec == 1) {
        	//if it is a black node meaning has elements so we do a recursive search
        	if(node.quadrants[1] != null) {
        		flag = node.quadrants[1].search(p);
        	}//if ends
        	//if it is a white node, then we return false
        	else {
        		flag = false;
        	}//else ends         	 
        	return flag;
        }//if ends      

        //+,- : Fourth Quadrant : South-East
        else if(sec == 3) {
        	//if it is a black node meaning has elements so we do a recursive search
        	if(node.quadrants[3] != null) {
        		flag = node.quadrants[3].search(p);
        	}//if ends
        	//if it is a white node, then we return false
        	else {
        		flag = false;
        	}//else ends 
        	return flag;
        }//if ends
        else {
        	flag = false;
        }//else ends
        return flag;
    }
  
    @Override
    public boolean search(KDPoint p){
        //throw new UnimplementedMethodException(); // ERASE THIS LINE AFTER YOU IMPLEMENT THIS METHOD!
    	boolean flag = false;
        flag = search_aux(this, p);
        
        return flag;
    }//search method ends
    
    //auxiliary function for height of first quadrant
    public int firstheight_NW(PRQuadNode[] quad) {
    	if(quad[0] == null) {
    		return -1;
    	}
    	else {
    		return quad[0].height();
    	}
    }//firstheight_NW method ends
    
    //auxiliary function for height of second quadrant
    public int secondheight_NE(PRQuadNode[] quad) {
    	if(quad[1] == null) {
    		return -1;
    	}
    	else {
    		return quad[1].height();
    	}
    }//secondheight_NE method ends
    
    //auxiliary function for height of third quadrant
    public int thirdheight_SW(PRQuadNode[] quad) {
    	if(quad[2] == null) {
    		return -1;
    	}
    	else {
    		return quad[2].height();
    	}
    }//thirdheight_SW method ends
    
    //auxiliary function for height of fourth quadrant
    public int fourthheight_SE(PRQuadNode[] quad) {
    	if(quad[3] == null) {
    		return -1;
    	}
    	else {
    		return quad[3].height();
    	}
    }//fourthheight_SE method ends
    
    @Override
    public int height(){
        //throw new UnimplementedMethodException(); // ERASE THIS LINE AFTER YOU IMPLEMENT THIS METHOD!
    	//System.out.println("height");
    	int first = firstheight_NW(this.quadrants);
    	int second = secondheight_NE(this.quadrants);
    	int third = thirdheight_SW(this.quadrants);
    	int fourth = fourthheight_SE(this.quadrants);
    	this.height = (Math.max(first, Math.max(second, Math.max(third, fourth))) + 1); 
    	
    	return this.height;    	
    }//height method ends

    @Override
    public int count(){
        //throw new UnimplementedMethodException(); // ERASE THIS LINE AFTER YOU IMPLEMENT THIS METHOD!
    	//System.out.println("Count");
    	return this.count;
    }//count method ends

    /**
     * Returns the children of the current node in the form of a Z-ordered 1-D array.
     * @return An array of references to the children of {@code this}. The order is Z (Morton), like so:
     * <ol>
     *     <li>0 is NW</li>
     *     <li>1 is NE</li>
     *     <li>2 is SW</li>
     *     <li>3 is SE</li>
     * </ol>
     */
    public PRQuadNode[] getChildren(){
        //throw new UnimplementedMethodException(); // ERASE THIS LINE AFTER YOU IMPLEMENT THIS METHOD!
    //	System.out.println("getChildren");
		return this.quadrants;
    }//getChildren method ends

    @Override
    public void range(KDPoint anchor, Collection<KDPoint> results, double range) {
        //throw new UnimplementedMethodException(); // ERASE THIS LINE AFTER YOU IMPLEMENT THIS METHOD!        
        //if we are within the range
        if(anchor.euclideanDistance(centroid) <= range) {
        	for (int i = 0; i < this.quadrants.length; i++) {
        		if(this.quadrants[i] != null) {
        			this.quadrants[i].range(anchor, results, range);
        		}//if ends
        	}//for loop ends
        }//if ends
        //if we are not within the range
        else {
        	for (int i = 0; i < this.quadrants.length; i++) {
        		if(this.quadrants[i] != null) {
        			if(this.quadrants[i].doesQuadIntersectAnchorRange(anchor, range)) {
            			this.quadrants[i].range(anchor, results, range);
            		}//if ends
        		}//if ends
        	}//for loop ends
        }//else ends
        
    }//range method ends
    
    //auxiliary function to find the target quadrant of the anchor for Nearest Neighbor and K-Nearest Neighbor
    public int nearest_helper(KDPoint anchor, KDPoint centroid) {
    	//-,+: North-West
    	if(anchor.coords[0] < centroid.coords[0] && centroid.coords[1] <= anchor.coords[1]) {
    		return 0;
    	}//else if ends
    	//+,+: North-East
    	else if(anchor.coords[0] >= centroid.coords[0] && centroid.coords[1] <= anchor.coords[1]) {
    		return 1;
    	}//else if ends
    	//-,-: South-West
    	else if(anchor.coords[0] < centroid.coords[0] && centroid.coords[1] > anchor.coords[1]) {
    		return 2;
    	}//else if ends
    	//+,-: South-East
    	else if(anchor.coords[0] >= centroid.coords[0] && centroid.coords[1] > anchor.coords[1]) {
    		return 3;
    	}//else if ends
    	//Or else does not exist
    	else {
    		return -1;
    	}//else ends
    	
    }//nn_helper method ends

    @Override
    public NNData<KDPoint> nearestNeighbor(KDPoint anchor, NNData<KDPoint> n)  {
        //throw new UnimplementedMethodException(); // ERASE THIS LINE AFTER YOU IMPLEMENT THIS METHOD!
    	int target = nearest_helper(anchor, this.centroid);
    	if(target >= 0 && this.quadrants[target] != null) {      			 
    		this.quadrants[target].nearestNeighbor(anchor, n);        			 
       	}//if ends    	
    	    	
        //go over all the children
        for (int i = 0; i < this.quadrants.length; i++) {
        	if(i != target && this.quadrants[i] != null) {
        		 if(this.quadrants[i].doesQuadIntersectAnchorRange(anchor, n.getBestDist()) || n.getBestDist() == -1.0) {        			 
        			 this.quadrants[i].nearestNeighbor(anchor, n);        			 
        		 }//if ends
        	}//if ends
        }//for loop ends                	
    	
    	return n;    	
    }//nearestNeighbor method ends

    @Override
    public void kNearestNeighbors(int k, KDPoint anchor, BoundedPriorityQueue<KDPoint> queue) {
        //throw new UnimplementedMethodException(); // ERASE THIS LINE AFTER YOU IMPLEMENT THIS METHOD!    	
    	int target = nearest_helper(anchor, this.centroid);

    	if(target >= 0 && this.quadrants[target] != null) {
    		this.quadrants[target].kNearestNeighbors(k, anchor, queue);
    	}//if ends  	
    	
        //go over all the children
	    for (int i = 0; i < this.quadrants.length; i++) {
	      	if(i != target && this.quadrants[i] != null) {
	      		if(queue.size() > 0) {
	      			if(queue.size() < k || this.quadrants[i].doesQuadIntersectAnchorRange(anchor, queue.last().euclideanDistance(anchor))) {
		      			this.quadrants[i].kNearestNeighbors(k, anchor, queue);
		      		}//inner if ends
	      		}//if ends
	      		else {
	      			this.quadrants[i].kNearestNeighbors(k, anchor, queue);
	      		}
	      	}//outer if ends
	      }//for loop ends   
	    
    }//kNearestNeighbors method ends
}

