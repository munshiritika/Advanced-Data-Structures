/*Name: Ritika Munshi
 * UID: 118345048
 */
package spatial.knnutils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.NoSuchElementException;

import spatial.exceptions.UnimplementedMethodException;


/**
 * <p>{@link BoundedPriorityQueue} is a priority queue whose number of elements
 * is bounded. Insertions are such that if the queue's provided capacity is surpassed,
 * its length is not expanded, but rather the maximum priority element is ejected
 * (which could be the element just attempted to be enqueued).</p>
 *
 * <p><b>YOU ***** MUST ***** IMPLEMENT THIS CLASS!</b></p>
 *
 * @author  <a href = "https://github.com/jasonfillipou/">Jason Filippou</a>
 *
 * @see PriorityQueue
 * @see PriorityQueueNode
 */
public class BoundedPriorityQueue<T> implements PriorityQueue<T>{

	/* *********************************************************************** */
	/* *************  PLACE YOUR PRIVATE FIELDS AND METHODS HERE: ************ */
	/* *********************************************************************** */

	//create queue using eu distance
	//used in k nearest
	
	ArrayList<T> elements = new ArrayList<T>();
	ArrayList<Double> priorities = new ArrayList<Double>();
	int count_num_elements;
	int size;

	/* *********************************************************************** */
	/* ***************  IMPLEMENT THE FOLLOWING PUBLIC METHODS:  ************ */
	/* *********************************************************************** */

	/**
	 * Constructor that specifies the size of our queue.
	 * @param size The static size of the {@link BoundedPriorityQueue}. Has to be a positive integer.
	 * @throws IllegalArgumentException if size is not a strictly positive integer.
	 */
	public BoundedPriorityQueue(int size) throws IllegalArgumentException{
		//throw new UnimplementedMethodException(); // ERASE THIS LINE AFTER YOU IMPLEMENT THIS METHOD!
		if (size < 1) {
			throw new IllegalArgumentException("Size is not positive integer");
		}
		else {
			this.size = size;
		}
		this.count_num_elements = 0;
	}//constructor method ends

	/**
	 * <p>Enqueueing elements for BoundedPriorityQueues works a little bit differently from general case
	 * PriorityQueues. If the queue is not at capacity, the element is inserted at its
	 * appropriate location in the sequence. On the other hand, if the object is at capacity, the element is
	 * inserted in its appropriate spot in the sequence (if such a spot exists, based on its priority) and
	 * the maximum priority element is ejected from the structure.</p>
	 * 
	 * @param element The element to insert in the queue.
	 * @param priority The priority of the element to insert in the queue.
	 */
	@Override
	public void enqueue(T element, double priority) {
		//throw new UnimplementedMethodException(); // ERASE THIS LINE AFTER YOU IMPLEMENT THIS METHOD!
		/*
		 * Example:
		 * 
		 * Adding:
		 * (A,2.4) (C,1.1) (E,9.4) (D,5.5)
		 * 
		 * has to look: (C,1.1) (A,2.1) (D,5.5) (E,9.4)
		 * 
		 * Adding (B,4.3)
		 * 
		 * if the capacity was 5
		 * has to be: (C,1.1) (A,2.1) (B,4.3) (D,5.5) (E,9.4)
		 * 
		 * if the capacity was 4
		 * has to be: (C,1.1) (A,2.1) (B,4.3) (D,5.5)
		 */
		//System.out.println("Element: "+element + " Priority: " + priority);
		//if map has no elements
		if(elements.size() == 0) {
			elements.add(element);	
			priorities.add(priority);
		}//if ends
		
		//if arraylist has elements
		else {
			if(elements.size() < size) {
				int i;
				for (i = priorities.size()-1; i >= 0; i--){ 
					if(priority >= priorities.get(i)) {
						break;
					}//if statement ends
				}//for loop ends				
				priorities.add(i+1, priority);
				elements.add(i+1, element);
			}//if statement ends		
			
			else {
				double lastelement = priorities.get(priorities.size() - 1);
				if(lastelement > priority) {
					priorities.remove(priorities.size() - 1);
					elements.remove(elements.size() - 1);
					
					int i;
					for (i = priorities.size()-1; i >= 0; i--){ 
						if(priority >= priorities.get(i)) {
							break;
						}//if statement ends
					}//for loop ends					
					priorities.add(i+1, priority);
					elements.add(i+1, element);
				}//inner if ends				
			}//inner else ends
		}//else ends	
		//System.out.println("Elements: "+elements + " and Priorities: "+priorities);
		count_num_elements++;
	}//enqueue method ends
	
	//insert an element and create node structure that contains infor about ele and priority
	//list of nodes which has ele and priority
	//mainatin insert > capac not expanded -- bound aspect
	//add if there is a closer node for instarnce, > size; anything in queue
	//return size of nearest neighbour

	@Override
	public T dequeue() {
		//throw new UnimplementedMethodException(); // ERASE THIS LINE AFTER YOU IMPLEMENT THIS METHOD!
		T result = null;
		if(elements.size() > 0) {
			result = elements.get(0);
			elements.remove(0);
			priorities.remove(0);
			count_num_elements--;	
		}
		else {
			result = null;
		}
		return result;
	}//dequeue method ends
	
	//remove first one
	//used when after you are done
	//no need to worry
	
	@Override
	public T first() {
		//throw new UnimplementedMethodException(); // ERASE THIS LINE AFTER YOU IMPLEMENT THIS METHOD!
		T result = null;
		if(elements.size() > 0) {
			result = elements.get(0);
		}
		else {
			result = null;
		}
		return result;
	}//first method ends
	
	/**
	 * Returns the last element in the queue. Useful for cases where we want to 
	 * compare the priorities of a given quantity with the maximum priority of 
	 * our stored quantities. In a minheap-based implementation of any {@link PriorityQueue},
	 * this operation would scan O(n) nodes and O(nlogn) links. In an array-based implementation,
	 * it takes constant time.
	 * @return The maximum priority element in our queue, or null if the queue is empty.
	 */
	public T last() {
		//throw new UnimplementedMethodException(); // ERASE THIS LINE AFTER YOU IMPLEMENT THIS METHOD!
		T result = null;
		if(elements.size() > 0) {
			result = elements.get(elements.size()-1);
		}
		else {
			result = null;
		}
		return result;
	}//last method ends

	/**
	 * Inspects whether a given element is in the queue. O(N) complexity.
	 * @param element The element to search for.
	 * @return {@code true} iff {@code element} is in {@code this}, {@code false} otherwise.
	 */
	public boolean contains(T element)
	{
		//throw new UnimplementedMethodException(); // ERASE THIS LINE AFTER YOU IMPLEMENT THIS METHOD!
		boolean flag = false;
		for (int i = 0; i < elements.size(); i++) {
			if(elements.get(i).equals(element)) {
				flag = true;
				break;
			}
			else {
				flag = false;
			}
		}
		
		return flag;
	}//contains method ends

	@Override
	public int size() {
		//throw new UnimplementedMethodException(); // ERASE THIS LINE AFTER YOU IMPLEMENT THIS METHOD!
		return elements.size();
	}//size method ends

	@Override
	public boolean isEmpty() {
		//throw new UnimplementedMethodException(); // ERASE THIS LINE AFTER YOU IMPLEMENT THIS METHOD!
		boolean flag = false;
		if(elements.size() == 0 || priorities.size() == 0) {
			flag = true;
		}//if ends
		else {
			flag = false;
		}//else ends
	
		return flag;
	}//isEmpty method ends

	@Override
	public Iterator<T> iterator() {
		//throw new UnimplementedMethodException(); // ERASE THIS LINE AFTER YOU IMPLEMENT THIS METHOD!
		ArrayList<T> elements_copy = elements;
		ArrayList<Double> priorities_copy = priorities;
		
		int len = elements_copy.size();
		return elements_copy.iterator();
		
		/*
		Iterator<T> iterator = elements_copy.iterator();
		
		while(iterator.hasNext()) {
		    return (Iterator<T>) (iterator.next());

		}
		
		/*
		
		Iterator<T> iterator = new Iterator<T>(){
			int index = 0;
				
			public boolean hasNext(){
				if (index < elements_copy.size()) {
					return true;
				}
				else {
					return false;
				}				
			}//hashNext ends here	
				
			public T next(){
//				if (!hasNext()) {
//	                throw new NoSuchElementException("Iterator does not have next");
//	            }
//				T result = elements_copy.get(index);
				//index++;
				//System.out.println(result);
				return elements_copy.get(index++);
	            //return result;
			}//next ends here
		};
		return iterator;
		
		 */
	}//iterator method ends
}
