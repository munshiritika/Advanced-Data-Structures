/*Name: Ritika Munshi
 * UID: 118345048
 */
package avlg;

import avlg.exceptions.UnimplementedMethodException;

import java.util.ArrayList;

import avlg.exceptions.EmptyTreeException;
import avlg.exceptions.InvalidBalanceException;

/** <p>{@link AVLGTree}  is a class representing an <a href="https://en.wikipedia.org/wiki/AVL_tree">AVL Tree</a> with
 * a relaxed balance condition. Its constructor receives a strictly  positive parameter which controls the <b>maximum</b>
 * imbalance allowed on any subtree of the tree which it creates. So, for example:</p>
 *  <ul>
 *      <li>An AVL-1 tree is a classic AVL tree, which only allows for perfectly balanced binary
 *      subtrees (imbalance of 0 everywhere), or subtrees with a maximum imbalance of 1 (somewhere). </li>
 *      <li>An AVL-2 tree relaxes the criteria of AVL-1 trees, by also allowing for subtrees
 *      that have an imbalance of 2.</li>
 *      <li>AVL-3 trees allow an imbalance of 3.</li>
 *      <li>...</li>
 *  </ul>
 *
 *  <p>The idea behind AVL-G trees is that rotations cost time, so maybe we would be willing to
 *  accept bad search performance now and then if it would mean less rotations. On the other hand, increasing
 *  the balance parameter also means that we will be making <b>insertions</b> faster.</p>
 *
 * @author YOUR NAME HERE!
 *
 * @see EmptyTreeException
 * @see InvalidBalanceException
 * @see StudentTests
 */



public class AVLGTree<T extends Comparable<T>> {

    /* ********************************************************* *
     * Write any private data elements or private methods here...*
     * ********************************************************* */
	
	public class AVLNode<T> {
		int height;
	    T key;
	    AVLNode<T> left;
	    AVLNode<T> right;
	    
	    public AVLNode(T element) {
			this.key = element;
			this.height = 0;
			this.left = null;
			this.right = null;
		}
	}
	
	private AVLNode<T> node; //this is the root of the tree
	final int balance; //this is the variable which will keep the track of the balance of the nodes of the tree

    /* ******************************************************** *
     * ************************ PUBLIC METHODS **************** *
     * ******************************************************** */

    /**
     * The class constructor provides the tree with the maximum imbalance allowed.
     * @param maxImbalance The maximum imbalance allowed by the AVL-G Tree.
     * @throws InvalidBalanceException if maxImbalance is a value smaller than 1.
     */
    public AVLGTree(int maxImbalance) throws InvalidBalanceException {
      //  throw new UnimplementedMethodException();       // ERASE THIS LINE AFTER YOU IMPLEMENT THIS METHOD!
    	this.node = null;
    	this.balance = maxImbalance;
    	//if maxImbalance is less than 1 throw an exception.
     	if(maxImbalance < 1) {
         	throw new InvalidBalanceException("Invalid imbalance exception thrown for constructor.");
        }
    }
            
    //auxiliary function for rotations
    public AVLNode<T> rotateRight(AVLNode<T> node) { 
    	AVLNode temp = node.left;
    	node.left = temp.right;
    	temp.right = node;
    	node.height = 1 + max(height_aux(node.left), height_aux(node.right));//update the height after the rotation is done
    	return temp;	
    }
    
    //auxiliary function for rotations
    public AVLNode<T> rotateLeft(AVLNode<T> node) {
    	AVLNode temp = node.right;
    	node.right = temp.left;
    	temp.left = node;
    	node.height = 1 + max(height_aux(node.left), height_aux(node.right));//update the height after the rotation is done
    	return temp;	
    }
    
    //auxiliary function for rotations
    public AVLNode<T> rotateLeftRight(AVLNode<T> node) {
    	node.left = rotateLeft(node.left);
    	node = rotateRight(node);
    	node.height = 1 + max(height_aux(node.left), height_aux(node.right));//update the height after the rotation is done
    	return node;
    }
    
    //auxiliary function for rotations
    public AVLNode<T> rotateRightLeft(AVLNode<T> node) {
    	node.right = rotateRight(node.right);
    	node = rotateLeft(node);
    	node.height = 1 + max(height_aux(node.left), height_aux(node.right));//update the height after the rotation is done
    	return node;
    }
    
    //auxiliary function to find max between two values  as we use this for the height comparison
    public int max(int a, int b)
    {
    	if (a > b) { 
    		return a; 
    	}
    	return b;
    }
    
    //auxiliary function for insertion of nodes and keys into our tree
    public AVLNode insertaux(T key, AVLNode<T> node) {
    	if (node == null) {
    	//	System.out.println("If");
    		node =  new AVLNode(key);
    		return node;
    	}
    	//if the value that we want to insert is less than the parent node
    	else if (key.compareTo(node.key) < 0) {
    		//System.out.println("else1");
    		node.left = insertaux(key, node.left); //we will insert to the left and have a recursive call over the left node
    		//if the height of left - right which gives us the balance is greater than the maxImbalance
            if (height_aux(node.left) - height_aux(node.right) > balance)
                if (key.compareTo(node.left.key) < 0)
                	node = rotateRight(node); //do a right rotation
                else																																			
                	node = rotateLeftRight(node); //have to do double rotation
            node.height = 1 + max(height_aux(node.left), height_aux(node.right)); //update the height of our node
        } 
    	//if the value that we want to insert is greater than the parent node
    	else if (key.compareTo(node.key) > 0) {
    		//System.out.println("else2");
        	node.right = insertaux(key, node.right);
        	//if the height of left - right which gives us the balance is greater than the maxImbalance
            if (height_aux(node.right) - height_aux(node.left) > balance)
                if (key.compareTo(node.right.key) > 0)
                	node = rotateLeft(node); //do left rotation
                else
                	node = rotateRightLeft(node); //have to do double rotation
            node.height = 1 + max(height_aux(node.left), height_aux(node.right));//update the height of node after rotations are done
        } 
    	
    	//node.height = max(height_aux(node.left), height_aux(node.right)) + 1;
    	return node;
    }
    
    /**
     * Insert key in the tree. You will <b>not</b> be tested on
     * duplicates! This means that in a deletion test, any key that has been
     * inserted and subsequently deleted should <b>not</b> be found in the tree!
     * s
     * @param key The key to insert in the tree.
     */    
    public void insert(T key) {
       // throw new UnimplementedMethodException();       // ERASE THIS LINE AFTER YOU IMPLEMENT THIS METHOD!
       node = insertaux(key, this.node); //calling our auxiliary function of insert over our root which is node
    }//insert function ends

    
     //auxiliary function to balance the tree after a certain deletion of a node is made
     public AVLNode balance_delete(AVLNode<T> node) {
    	 
    	if(node == null) {
    		return node;
    	}
    	 
    	int balance_f =  balance_factor(node); //have our balance of a node stored in a variable
    	
    	 //Right Heavy
    	 if (balance_f > balance) { //if the balance of the node we are in is greater than our maxImbalance
    		 if(balance_factor(node.left) >= 0) { //check for left node balance
    			 node = rotateRight(node);//have to do a right rotation
    		 }
    		 else if(balance_factor(node.left) < 0) { //check for left node balance
    			 node.left = rotateLeft(node.left); //do a left rotation on our left node
    	         node = rotateRight(node); //then do right rotation on our node
    		 }
    	 }
  	  
    	// Left Heavy
    	  if (balance_f < (-balance)) {//if the balance of the node we are in is less than our (-maxImbalance)
    		  if(balance_factor(node.right) <= 0) {//check for right node balance
    			  node = rotateLeft(node); //do a left rotation on our node
    		  }
    		  else if(balance_factor(node.right) > 0) {//check for right node balance
    			  node.right = rotateRight(node.right);//have to do a right rotation on our right node
    	          node = rotateLeft(node);//then do left rotation on our node
    		  }
    	  }
    	  
    	 node.height = 1 + max(height_aux(node.left), height_aux(node.right)); //update the height of the node after balancing is done
    	 return node; 
     }
    
     //auxiliary function created for deletion as we have to do successors to find the next element while deletion
     public AVLNode find_Replacement(AVLNode<T> node) {
    	 AVLNode<T> val = node.right;
    	 while(val.left != null) 
    		 val = val.left;
    	 return val;
     }
     
    //auxiliary function for delete
    public AVLNode delete_aux(T key, AVLNode<T> node) { //throw new UnimplementedMethodException(); 
    	
    	//If our node is null, return the node itself
    	if (node == null) {
    		return null;
    	}
    	
    	//If the element to be deleted is smaller than the node element, it has to go to the left and do a recursive call
    	else if ((key).compareTo(node.key) < 0) {
    		node.left = delete_aux(key, node.left);
    	}
    	
    	//If the element to be deleted is larger than the node element, it has to go to the right and do a recursive call
    	else if ((key).compareTo(node.key) > 0) {
    		node.right = delete_aux(key, node.right);
    	}
    	
    	//if either our left or else right node is null
    	else if (node.left == null || node.right == null) {
    		if (node.left == null) { //if left is null then go to right
    			node = node.right;
    		}
    		else if (node.right == null) { //if right is null go to our left
    			node = node.left;
    		}
    	}
    	
    	else {//if none of the above are true here we do our deletion and rotations and inorder successor
    		AVLNode<T> r = find_Replacement(node);
    		node.key = r.key; //copy r's content to node
    		node.right = delete_aux(r.key, node.right);    		
    	} 
    	
        return balance_delete(node);  //return by rebalancing the tree after deletion 	
    }//auxiliary function ends
    
    /**
     * Delete the key from the data structure and return it to the caller.
     * @param key The key to delete from the structure.
     * @return The key that was removed, or {@code null} if the key was not found.
     * @throws EmptyTreeException if the tree is empty.
     */
    public T delete(T key) throws EmptyTreeException {
       // throw new UnimplementedMethodException();       // ERASE THIS LINE AFTER YOU IMPLEMENT THIS METHOD!
    	if(node == null) { //if the tree is empty throw an exception.
    		throw new EmptyTreeException("Empty Tree Exception thrown for delete method.");    		
    	}
    	if(search(key) != null) { //if the key we want to delete is present in the tree then only move further which we check using search method
    		this.node = delete_aux(key, this.node);
			return key;
		}
    	else //if the key is not present in the tree then we do nothing and return null.
    		return null;

    }
    
    //if that value does not exist return null
    //if that value exist then you do the remaining rotations
    
    
    //auxiliary function for search
    public T search_aux(AVLNode<T> node, T key) {
    	//if node is null return null as have nothing to search for
    	if(node == null) {
    		return null;
    	}
    	//if the key that we are searching is less than the key of the parent node go to the left and do recursive search still you don't find
    	else if ((key).compareTo(node.key) < 0) {
    		return search_aux(node.left, key);
    	}
    	//if the key that we are searching is greater than the key of the parent node go to the right and do recursive search still you don't find
    	else if ((key).compareTo(node.key) > 0) {
    	    return search_aux(node.right, key); 
    	}
    	//as soon as they are equal then just return the key 
		return node.key; 
    }//auxiliary function ends
    
    /**
     * <p>Search for key in the tree. Return a reference to it if it's in there,
     * or {@code null} otherwise.</p>
     * @param key The key to search for.
     * @return key if key is in the tree, or {@code null} otherwise.
     * @throws EmptyTreeException if the tree is empty.
     */
    public T search(T key) throws EmptyTreeException {
       // throw new UnimplementedMethodException();       // ERASE THIS LINE AFTER YOU IMPLEMENT THIS METHOD!    	
    	if(node == null) {//if node is null meaning tree is empty throw an exception
    		throw new EmptyTreeException("Empty Tree Exception thrown for search method.");   
    	}
    	//if tree is not empty then do search using our auxiliary function
    	return search_aux(this.node, key);
    }

    //auxiliary function to compute the balance factor of the tree
    public int balance_factor(AVLNode<T> node)
    {
    	//if empty then nod will have a balance of 0
        if (node == null) { 
        	return 0; 
        }
//        if(node.left != null && node.right == null) {
//        	return 1;
//        }
//        if(node.left == null && node.right != null) {
//        	return -1;
//        }
        //if node is not null then height of left - height of right nodes gives us the balance of the node
        return height_aux(node.left) - height_aux(node.right);
    }//auxiliary function ends
    
    /**
     * Retrieves the maximum imbalance parameter.
     * @return The maximum imbalance parameter provided as a constructor parameter.
     */
    public int getMaxImbalance(){
        //throw new UnimplementedMethodException();       // ERASE THIS LINE AFTER YOU IMPLEMENT THIS METHOD!
        return balance;
    }
    
    //auxiliary function to get the height from a specific node of a tree
    public int height_aux(AVLNode node) {
    	//if node is null then height becomes -1
        if(node == null) {
    		return -1;
    	}
        //if node is not null
        else {
        //	int left_node = height_aux(node.left); //height of left node
        	//int right_node = height_aux(node.right); //height of right node
        	if(height_aux(node.left) < height_aux(node.right)) {//if height of left node is less than the height of right node
        		return (height_aux(node.right) +1); //height of right node + 1
        	}
        	else {
        		return (height_aux(node.left)+1); //height of left node + 1
        	}
        	
        }
    	//return node.height;
    }//auxiliary function ends
    
    /**
     * <p>Return the height of the tree. The height of the tree is defined as the length of the
     * longest path between the root and the leaf level. By definition of path length, a
     * stub tree has a height of 0, and we define an empty tree to have a height of -1.</p>
     * @return The height of the tree. If the tree is empty, returns -1.
     */
    public int getHeight() {
       // throw new UnimplementedMethodException();       // ERASE THIS LINE AFTER YOU IMPLEMENT THIS METHOD!
    	if(this.node == null) {
    		return -1;
    	}
    	return this.node.height;
    }

    /**
     * Query the tree for emptiness. A tree is empty iff it has zero keys stored.
     * @return {@code true} if the tree is empty, {@code false} otherwise.
     */
    public boolean isEmpty() {
      //  throw new UnimplementedMethodException();       // ERASE THIS LINE AFTER YOU IMPLEMENT THIS METHOD!
    	if(this.node == null) {
    		return true;
    	}
    	return false;
    }

    /**
     * Return the key at the tree's root node.
     * @return The key at the tree's root node.
     * @throws  EmptyTreeException if the tree is empty.
     */
    public T getRoot() throws EmptyTreeException{
       // throw new UnimplementedMethodException();       // ERASE THIS LINE AFTER YOU IMPLEMENT THIS METHOD!	
    	if (this.node == null) {
    		throw new EmptyTreeException("Empty exception thrown for getRoot method.");
    	}
    	return this.node.key;
    }

    //auxiliary function for the isBST to check for binary search tree property
    public boolean bal(AVLNode<T> node) {
    	//if node is null we know its balance so return true
    	if(node == null) {
    		return true;
    	}
    	//if our left node and right node both are not null
    	if(node.left != null && node.right != null) {
    		//if left node key is less than the parent key and right node key is greater than the parent key
    		if((node.left.key).compareTo(node.key) < 0 && (node.right.key).compareTo(node.key) > 0) {
    			//property is satisfied return true
    			return true;
    		}
    	}
    	//if right node is null but left node is not null
    	if(node.right == null && node.left != null) {
    		//if left node key is less than the parent key
    		if((node.left.key).compareTo(node.key) < 0) {
    			//property is satisfied return true
    			return true;
    		}
    	}
    	//if left node is null but right node is not null
    	if(node.right != null && node.left == null) {
    		//if right node key is greater than the parent node key
    		if((node.right.key).compareTo(node.key) > 0) {
    			//property is satisfied return true
    			return true;
    		}
    	}
    	return (bal(node.left) || bal(node.right)); //return by doing recursive over balance as we have to further go down
    }//auxiliary function ends

    /**
     * <p>Establishes whether the AVL-G tree <em>globally</em> satisfies the BST condition. This method is
     * <b>terrifically useful for testing!</b></p>
     * @return {@code true} if the tree satisfies the Binary Search Tree property,
     * {@code false} otherwise.
     */
    public boolean isBST() {
    	// throw new UnimplementedMethodException();       // ERASE THIS LINE AFTER YOU IMPLEMENT THIS METHOD!
    	if(bal(this.node) == true) {
    		return true;	
    	}
    	return true; 
    }
    
  //auxiliary function for the isAVLGBalanced
    public boolean avlg(AVLNode<T> node) {
    	//AVLNode<T> nodes=node;
    	//if node is null return true as it is balanced
    	if(node == null) {
    		return true;
    	}
    	//if our left node and right node both are not null
    	if(node.left != null && node.right != null) {
    		//if height of left node - height of right node is less than our maxImbalance then return true
    		if((Math.abs(height_aux(node.left) - height_aux(node.right))) < balance) {
    			return true;
    		}
    	}
    	//if right node is null but left node is not null
    	if(node.right == null && node.left != null) {
    		//if height of left node - height of right node is less than our maxImbalance then return true
    		if((Math.abs(height_aux(node.left) - height_aux(node.right))) < balance) {
    			return true;
    		}
    	}
    	//if left node is null but right node is not null
    	if(node.right != null && node.left == null) {
    		//if height of left node - height of right node is less than our maxImbalance then return true
    		if((Math.abs(height_aux(node.left) - height_aux(node.right))) < balance) {
    			return true;
    		}
    	}
    	return (avlg(node.left) || avlg(node.right)); //return by doing recursive over heights with respect to balances as we have to further go down
    }//auxiliary function ends


    /**
     * <p>Establishes whether the AVL-G tree <em>globally</em> satisfies the AVL-G condition. This method is
     * <b>terrifically useful for testing!</b></p>
     * @return {@code true} if the tree satisfies the balance requirements of an AVLG tree, {@code false}
     * otherwise.
     */
    public boolean isAVLGBalanced() {
      //  throw new UnimplementedMethodException();       // ERASE THIS LINE AFTER YOU IMPLEMENT THIS METHOD!
    	if (avlg(this.node) == true) {
    		return true;
    	}
    	return false;
    }

    /**
     * <p>Empties the AVL-G Tree of all its elements. After a call to this method, the
     * tree should have <b>0</b> elements.</p>
     */
    public void clear(){
        //throw new UnimplementedMethodException();       // ERASE THIS LINE AFTER YOU IMPLEMENT THIS METHOD!
    	this.node = null;
    }
    
    //auxiliary function to count the number of nodes in the tree
    private int no_of_nodes(AVLNode<T> node)
    {
    	int count = 1;
    	//if node is null then count is 0
        if (node == null) {
        	return 0;
        }      
        //if node is not null
        count = count + no_of_nodes(node.left); //do a recursive call over the left nodes to count the number of nodes on the left side of the tree
        count = count + no_of_nodes(node.right);//do a recursive call over the right nodes to count the number of nodes on the right side of the tree
        return count;
    }
     
    /**
     * <p>Return the number of elements in the tree.</p>
     * @return  The number of elements in the tree.
     */
    public int getCount(){
       // throw new UnimplementedMethodException();       // ERASE THIS LINE AFTER YOU IMPLEMENT THIS METHOD!
    	return (no_of_nodes(this.node));
    }   
  
}
