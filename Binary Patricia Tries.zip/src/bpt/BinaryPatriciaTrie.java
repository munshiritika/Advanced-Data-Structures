//Name: Ritika Munshi
//UID: 118345048
package bpt;

import bpt.UnimplementedMethodException;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Queue;
import java.util.Stack;

/**
 * <p>{@code BinaryPatriciaTrie} is a Patricia Trie over the binary alphabet &#123;	 0, 1 &#125;. By restricting themselves
 * to this small but terrifically useful alphabet, Binary Patricia Tries combine all the positive
 * aspects of Patricia Tries while shedding the storage cost typically associated with tries that
 * deal with huge alphabets.</p>
 *
 * @author Ritika Munshi
 */
public class BinaryPatriciaTrie {

    /* We are giving you this class as an example of what your inner node might look like.
     * If you would prefer to use a size-2 array or hold other things in your nodes, please feel free
     * to do so. We can *guarantee* that a *correct* implementation exists with *exactly* this data
     * stored in the nodes.
     */
    private static class TrieNode {
        private TrieNode left, right;
        private String str;
        private boolean isKey;

        // Default constructor for your inner nodes.
        TrieNode() {
            this("", false);
        }

        // Non-default constructor.
        TrieNode(String str, boolean isKey) {
            left = right = null;
            this.str = str;
            this.isKey = isKey;
        }
    }

    private TrieNode root;
    int size;

    /**
     * Simple constructor that will initialize the internals of {@code this}.
     */
    public BinaryPatriciaTrie() {
        //throw new UnimplementedMethodException(); // ERASE THIS LINE AFTER YOU IMPLEMENT THE METHOD!
    	this.root = null;
    	this.size = 0;
    }//constructor ends
    
    public boolean search_aux(TrieNode node, String key) {
    	String keystr = null, nodestr = null, remainstr = null;
    	int len = 0, start = 0, n = 0, i = 0, keylen = 0, updatelen = 0;
    	boolean flag = false, check = false;
    	char c = 0;
    	String keys = key;
    	
    	if(node != null) {
        	do {
        		c = key.charAt(0);
        		if(c == '0') {
        			node = node.left;
        		}//if ends
        		else {
        			node = node.right;
        		}//else ends
        		if(node != null) {
        			//key stored in the node
        			nodestr = node.str; 
        			keylen = key.length();
        			if(keylen < nodestr.length()) { //the key we are searching for does not exist so return false and break
        				flag = false;
        				break;
        			}//if ends
        			
        			else if(keylen == nodestr.length()) {
        				//if key length matches with the node string length and is stored with true then return true
        				if(key.equals(nodestr)) {
        					if(node.isKey == true) {
        						flag = true;
        						break;
        					}//inner if ends
        					//if key length matches with the node string length and but is not stored then return false
        					else {
        						flag = false;
        						break;
        					}//inner else ends
        				}//if ends
        			}//else if ends
        			
        			else {
        				check = key.startsWith(nodestr); //if our key is a prefix of the node string
        				if(check == true) {
        					len = nodestr.length(); //the length of characters that prefix matches from nodestr
        					n = n + nodestr.length();
        					updatelen = keys.length() - n; //remaining characters length of our key
        					if(updatelen > 0) {
        						remainstr = key.substring(len, key.length());
        						key = remainstr;
        					}//inner if ends
        				}//if check ends        				
        			}////else (nodestr.length() <= key.length()) ends          			
        		}//inner if(node != null)
        		//if our node is Null
        		else {
        			flag = false;
        			break;
        		}//else ends     		
        	}while(n < keys.length() || node != null);   //want to loop until we go through our entire key search in the binary patricia trie  
    	}//outer if(node != null)    	
    	//outer if node or root is null
    	else {
    		//If node is null and the very beginning of our insertion then we add to the left and right of the root based on the first character
    		flag = false;
    	}//outer else
    	return flag;
    	
    }//search_aux method ends
    	
  

    /**
     * Searches the trie for a given key.
     *
     * @param key The input {@link String} key.
     * @return {@code true} if and only if key is in the trie, {@code false} otherwise.
     */
    public boolean search(String key) {
        //throw new UnimplementedMethodException(); // ERASE THIS LINE AFTER YOU IMPLEMENT THE METHOD!
    	boolean flag = false;
    	
    	flag = search_aux(this.root, key);
    	return flag;   	
    }//search method ends
   
    //auxiliary function for insert 
    public boolean insert_aux(TrieNode node, String key) {
    	String keystr = null, nodestr = null, remainstr = null, remainnode = null, remainkey = null, str = null;
    	int len = 0, start = 0, n = 0, j = 0, l = 0;
    	boolean flag = false, check = false, check1 = false;
    	char c = 0;
    	TrieNode parent = node;
    	TrieNode nodeleft = node, noderight = node;
    	
    	if(node != null) {
        	do {
        		parent = node;
        		if (node != null) {
        			c = key.charAt(0);
            		if(c == '0') {
            			parent = node;
            			node = node.left;
            		}//if ends
            		else {
            			parent = node;
            			node = node.right;
            		}//else ends
            		if(node != null) {
            			//key stored in the node
            			nodeleft = node;
            			noderight = node;
            			nodestr = node.str; 
            			if(key.length() < nodestr.length()) {            				
            					check1 = nodestr.startsWith(key);
            					if(check1 == true && node.left == null && node.right == null) {
            						str = nodestr.substring(key.length(), nodestr.length());
            						//node = new TrieNode(key, true);
            						node.str = key;
            						node.isKey = true;
            						if(str.charAt(0) == '0') {
            							node.left = new TrieNode(str, true);
            							flag = true;
            						}//if ends
            						else {
            							node.right = new TrieNode(str, true);
            							flag = true;
            						}//else ends
            						break;
            					}//outer if ends
            					else if (check1 == true && node.left != null || node.right != null) {            						
                        				//length of the key stored in the node
                                		len = nodestr.length();	
                                		//stores the number of characters absorbed
                                		n = n + len;
                        				for(j = 0; j < key.length(); j++) {
                        					if(nodestr.charAt(j) != key.charAt(j)) {
                        						break;
                        					}//if ends
                        				}//for loop ends
                        				if(j < nodestr.length()) {
                        					remainnode = nodestr.substring(j);
                            				remainkey = key.substring(j);
                            				
                            				if(node.left != null && node.right != null) {
                            					nodeleft = node.left;
                            					noderight = node.right;
                            				}//if ends
                            				else {
                            					nodeleft = null;
                            					noderight = null;
                            				}//else ends
                            				
                            				//updating the node string with the characters that match based on splitting
                            				node.str = key.substring(0, j);
                            				node.isKey = true;
                            				                    				
                            				//if the node that we are splitting has no children further
                            				if(node.right == null && node.left == null) {
                            					if(remainnode.charAt(0) == '0') { 
                            						TrieNode newnode = new TrieNode(remainnode, true);//node we want to insert from splitting
                            						node.left = newnode;
                                					flag = true;
                                				}//inner if ends
                                				else { 
                                					TrieNode newnode = new TrieNode(remainnode, true);//node we want to insert from splitting
                                					node.right = newnode;
                                					flag = true;
                                				}//else ends
                                				if(remainkey.charAt(0) == '0') { 
                                					TrieNode newkeynode = new TrieNode(remainkey, true);//node we want to insert from splitting
                                					node.left = newkeynode;
                                					flag = true;
                                				}//inner if ends
                                				else { 
                                					TrieNode newkeynode = new TrieNode(remainkey, true);//node we want to insert from splitting
                                					node.right = newkeynode;
                                					flag = true;
                                				}//else ends
                                				break;
                            				}//if ends
                            				else {
                            					if(remainnode.charAt(0) == '0') { 
                            						if(nodeleft == null || noderight == null) {
                            							TrieNode newnode = new TrieNode(remainnode, true);//node we want to insert from splitting
                            							node.left = newnode;
                            						}//inner if ends
                            						else {
                            							TrieNode newnode = new TrieNode(remainnode, false);//node we want to insert from splitting
                                						node.left = newnode;
                                    					node.left.left = nodeleft;
                                    					node.left.right = noderight;
                            						}//else ends
                            						node.right = null;
                                					flag = true;
                                				}//if ends
                            					else { 
                            						if(nodeleft == null || noderight == null) {
                            							TrieNode newnode = new TrieNode(remainnode, true);//node we want to insert from splitting
                            							node.right = newnode;
                            						}//inner if ends
                            						else {
                            							TrieNode newnode = new TrieNode(remainnode, false);//node we want to insert from splitting
                                    					node.right = newnode;
                                    					node.right.left = nodeleft;
                                    					node.right.right = noderight;
                            						}//else ends
                            						node.left = null;
                                					flag = true;
                                				}//else ends
                            					break;
                            				}//else ends
                            				//break;                    				
                        				}//if(j < nodestr.length())                        			
            					}//else if ends            			
            			}//if ends
            			else {
            				//if nodestr is the prefix of our key; such as if 11 (nodestr) is prefix of 11011 (key)
                			check = key.startsWith(nodestr);
                			if(check == true) {
                				//length of the key stored in the node
                        		len = nodestr.length();	
                        		//stores the number of characters absorbed
                        		n = n + len;
                        		if(key.length() > len) {
                        			//get the number of characters from key with respect to the node string value
                            		remainstr = key.substring(len);
                            		key = remainstr;	
                        		}//if ends
                        		else if(key.length() == len) {
                        			if(key.equals(nodestr)) {
                        				if(node.isKey == false) {
                        					node.isKey = true;
                        					flag = true;
                        					break;
                        				}//if ends
                        			}//if ends
                        		}//else if ends
                			}//if ends
                			//when it is not a prefix is when we have to split into two children which is case 3
                			else {
                				//length of the key stored in the node
                        		len = nodestr.length();	
                        		//stores the number of characters absorbed
                        		n = n + len;
                				for(j = 0; j < nodestr.length(); j++) {
                					if(nodestr.charAt(j) != key.charAt(j)) {
                						break;
                					}//if ends
                				}//for loop ends
                				if(j < nodestr.length()) {
                					remainnode = nodestr.substring(j);
                    				remainkey = key.substring(j);
                    				
                    				if(node.left != null && node.right != null) {
	                    				nodeleft = new TrieNode(node.left.str, true);//left child of the node we are splitting
	                    				noderight = new TrieNode(node.right.str, true);//right child of the node we are splitting
                    				}//if ends
                    				else {
                    					nodeleft = null;
                    					noderight = null;
                    				}//else ends
                    				
                    				//updating the node string with the characters that match based on splitting
                    				node.str = key.substring(0, j);
                    				node.isKey = false;
                    				                    				
                    				//if the node that we are splitting has no children further
                    				if(node.right == null && node.left == null) {
                    					if(remainnode.charAt(0) == '0') { 
                    						TrieNode newnode = new TrieNode(remainnode, true);//node we want to insert from splitting
                    						node.left = newnode;
                        					flag = true;
                        				}//if ends
                        				else { 
                        					TrieNode newnode = new TrieNode(remainnode, true);//node we want to insert from splitting
                        					node.right = newnode;
                        					flag = true;
                        				}//else ends
                        				if(remainkey.charAt(0) == '0') { 
                        					TrieNode newkeynode = new TrieNode(remainkey, true);//node we want to insert from splitting
                        					node.left = newkeynode;
                        					flag = true;
                        				}//if ends
                        				else { 
                        					TrieNode newkeynode = new TrieNode(remainkey, true);//node we want to insert from splitting
                        					node.right = newkeynode;
                        					flag = true;
                        				}//else ends
                        				break;
                    				}//if ends
                    				else {
                    					if(remainnode.charAt(0) == '0') { 
                    						if(nodeleft == null || noderight == null) {
                    							TrieNode newnode = new TrieNode(remainnode, true);//node we want to insert from splitting
                    							node.left = newnode;
                    						}//if ends
                    						else {
                    							TrieNode newnode = new TrieNode(remainnode, false);//node we want to insert from splitting
                        						node.left = newnode;
                            					node.left.left = nodeleft;
                            					node.left.right = noderight;
                    						}//else ends                    						
                        					flag = true;
                        				}//if ends
                    					else { 
                    						if(nodeleft == null || noderight == null) {
                    							TrieNode newnode = new TrieNode(remainnode, true);//node we want to insert from splitting
                    							node.right = newnode;
                    						}//if ends
                    						else {
                    							TrieNode newnode = new TrieNode(remainnode, false);//node we want to insert from splitting
                            					node.right = newnode;
                            					node.right.left = nodeleft;
                            					node.right.right = noderight;
                    						}//else ends                  						
                        					flag = true;
                        				}//else ends
                    					if(remainkey.charAt(0) == '0') { 
                    						TrieNode newkeynode = new TrieNode(remainkey, true);//node we want to insert from splitting
                    						node.left = newkeynode;
                        					flag = true;
                        				}//if ends
                        				else { 
                        					TrieNode newkeynode = new TrieNode(remainkey, true);//node we want to insert from splitting
                    						node.right = newkeynode;
                        					flag = true;
                        				}//else ends
                    					break;
                    				}//else ends
                    				//break;                    				
                				}//if(j < nodestr.length())
                			}//else
            			}//outer else            			
            		}//inner if(node != null)
            		//if our node which is our child is Null, we hit case 1: Allocate a new node
            		else {
            			if(key.charAt(0) == '0') {
                			flag = true;                			
                			node = new TrieNode(key, true);
                			parent.left = node; 			
                		}//if ends
                		else
                		{
                			flag = true;
                			node = new TrieNode(key, true);  
                			parent.right = node;
                		}//else ends
            			break;
            		}//else           		
        		}//inner if node is not null
        		else {
        			node = new TrieNode("", false);
        			if(key.charAt(0) == '0') {
            			flag = true;
            			node.left = new TrieNode(key, true);  			
            		}//if ends
            		else
            		{
            			flag = true;
            			node.right = new TrieNode(key, true);    			
            		}//else ends
        		}//else ends        		      		
        	}while(n < key.length() || node != null);   //want to loop until we go through our entire key search in the binary patricia trie  
    	}//outer if(node != null)
    	
    	//outer if node or root is null
    	else {
    		//If node is null and the very beginning of our insertion then we add to the left and right of the root based on the first character
    		node = new TrieNode("", false);
    		if(key.charAt(0) == '0') {
    			flag = true;
    			node.left = new TrieNode(key, true);  			
    		}//if ends
    		else
    		{
    			flag = true;
    			node.right = new TrieNode(key, true);    			
    		}//else ends
    	}//outer else
    	return flag;
    }//insert_aux method ends      
    
    /**
     * Inserts key into the trie.
     *
     * @param key The input {@link String}  key.
     * @return {@code true} if and only if the key was not already in the trie, {@code false} otherwise.
     */
    public boolean insert(String key) {
        //throw new UnimplementedMethodException(); // ERASE THIS LINE AFTER YOU IMPLEMENT THE METHOD!
    	boolean flag = false;
    	TrieNode node = new TrieNode("", flag);
    	
    	//If the key is already present then we return false and do nothing
    	if(search(key) == true) {
    		flag = false;
    		return false;
    	}//if ends
    	else {
    		if(this.root == null) {
        		this.root = new TrieNode("", false);
        		if(key.charAt(0) == '0') {
        			this.root.left = new TrieNode(key, true);
        			flag = true;
        		}//if ends
        		else
        		{
        			this.root.right = new TrieNode(key, true);
        			flag = true;
        		}//else ends
        	}//if ends
        	//If the key does not exist and we have 4 conditions to encounter for insertion
        	else {
        		flag = insert_aux(this.root, key);
        	}//else ends
    	}//outer else ends
    
    	size++;
    	return flag;    	
    }//insert method ends
    
    
    public boolean delete_aux(TrieNode node, String key) {
    	String keystr = null, nodestr = null, remainstr = null, remainnode = null, remainkey = null,leftstr = null, rightstr=null;
    	int len = 0, start = 0, n = 0, j = 0, i = 0, keylen = 0, nodelen = 0;
    	boolean flag = false, check = false;
    	TrieNode parent = node, par = node, parright = node, parleft = node;
    	char c = 0;
    	String keys = key;
    	
    	if(node != null) {
    		do {  
    			parent = node;
    			c = key.charAt(0);
        		if(c == '0') {
        			parent = node;
        			node = node.left;
        		}//if ends
        		else {
        			parent = node;
        			node = node.right;
        		}//else ends
        		if(node != null) {
        			nodestr = node.str;
        			keylen = key.length();
        			if(keylen < nodestr.length()) { //the key we are searching for does not exist so return false and break
        				flag = false;
        				break;
        			}//if ends
        			else {
            			check = key.startsWith(nodestr); //if our key is the prefix of the node's key value
            			if(check == true) {
            				if(key.length() > nodestr.length()) {
            					keystr = key.substring(0, nodestr.length());          				
                        		len = nodestr.length();			//length of the key stored in the node
                        		n = n + len; 					//stores the number of characters absorbed
                        		remainstr = key.substring(len); //get the number of characters from key with respect to the node string value
                        		key = remainstr;
            				}//inner if ends
            				else {
            					len = nodestr.length();
            					n = n + len;
            					keystr = key;
            				}//else ends
            			}//if ends
            			else {
            				flag = false;
            				break;
            			}//else ends
            			if(nodestr.equals(keystr)) {            				
            				if (n == keys.length()) {
            					//if the node is the left child of the parent
                				if(parent.left == node) { 
                					//case 1: Unset the Bit when the node has more than one children
                					if(node.left != null && node.right != null) {
                						node.isKey = false;
                						flag = true;
                						break;
                					}//if ends
                					//case 2: when has only one child then merge with parent
                					else if (node.left == null && node.right != null) {
                						parent.left = new TrieNode(node.str+node.right.str, true);
                    					//node = new TrieNode(node.str+node.right.str, true);
                    					node.right = null;
                    					parent.left.right = null;
                    					flag = true;
                    					break;
                					}//else if ends
                					//case 2: when has only one child then merge with parent
                					else if (node.left != null && node.right == null) {  
                    					parent.left = new TrieNode(node.str+node.left.str, true);
                    					node.left = null;
                    					parent.left.left = null;
                    					flag = true;
                    					break;
                					}//else if ends
                					//case 3: if the node we are deleting has no child then remove that node
                					else if(node.left == null && node.right == null) { 
                						node = null;
                						parent.left = null;
                						flag = true;
                						if(parent != this.root && parent.isKey == false) {
                							if(parent.right != null) {
                								parright = parent.right;
                								String k = parent.str + parright.str;
                								parent.str = k; 
                								parent.isKey = parright.isKey;
                								parent.left = parright.left;
                								parent.right = parright.right;                								
                							}//inner if ends
                						}//outer if ends
                						break;
                					}//else if ends  
                				}//if(parent.left == node)
                				//if the node is the right child of the parent
                				
                				else if(parent.right == node) { 
                					//case 1: Unset the Bit when the node has more than one children
                					if(node.left != null && node.right != null) {
                						node.isKey = false;
                						flag = true;
                						break;
                					}//if ends
                					//case 3: if the node we are deleting has no child then remove that node
                					else if(node.left == null && node.right == null) { 
                						node = null;
                						parent.right = null;
                						flag = true;
                						if(parent != this.root && parent.isKey != true) {
                							if(parent.left != null) {
                								parleft = parent.left;
                								String k = parent.str + parleft.str;
                								parent.str = k;
                								parent.isKey = parleft.isKey;
                								parent.left = parleft.left;
                								parent.right = parleft.right;
                							}//inner if ends
                						}//outer if ends
                						break;
                					}//else if ends
                					//case 2: when has only one child then merge with parent
                					else if(node.right == null && node.left != null) {
                    					parent.right = new TrieNode(node.str+node.left.str, true);
                    					node.left = null;
                    					parent.right.left = null;
                    					flag = true;
                    					break;
                					}//else if ends
                					//case 2: when has only one child then merge with parent
                					else if(node.right != null && node.left == null) {
                    					parent.right = new TrieNode(node.str+node.right.str, true);
                    					//node = new TrieNode(node.str+node.right.str, true);
                    					node.right = null;
                    					parent.right.right = null;
                    					flag = true;
                    					break;
                					}//inner else if ends                					
                				}//else if ends  		                				
            				}//if n == keys.length()
            				else {
            					continue;
            				}//else ends 	            				
            			}//if(nodestr.equals(key)) ends 
        			}//else ends       			
        		}//if node != null ends   
    		}while(node != null || n < keys.length());
    	}//if node != null ends 
    	
    	return flag;
    }//delete_aux method ends


    /**
     * Deletes key from the trie.
     *
     * @param key The {@link String}  key to be deleted.
     * @return {@code true} if and only if key was contained by the trie before we attempted deletion, {@code false} otherwise.
     */
    public boolean delete(String key) {
        //throw new UnimplementedMethodException(); // ERASE THIS LINE AFTER YOU IMPLEMENT THE METHOD!
    	boolean flag = false;
    	
    	if(search(key) == false) {
    		flag = false;
    		return false;
    	}//if ends
    	else {
    		flag = delete_aux(this.root, key);
    	}//else ends
    	
    	size--;
    	return flag;
    }//delete method ends

    /**
     * Queries the trie for emptiness.
     *
     * @return {@code true} if and only if {@link #getSize()} == 0, {@code false} otherwise.
     */
    public boolean isEmpty() {
        //throw new UnimplementedMethodException(); // ERASE THIS LINE AFTER YOU IMPLEMENT THE METHOD!
    	boolean flag = false;
    	
    	if (getSize() == 0) {
    		flag = true;
    	}//if ends
    	else {
    		flag = false;
    	}//else ends
    	
    	return flag;
    }//isEmpty method ends

    /**
     * Returns the number of keys in the tree.
     *
     * @return The number of keys in the tree.
     */
    public int getSize() {
       // throw new UnimplementedMethodException(); // ERASE THIS LINE AFTER YOU IMPLEMENT THE METHOD!
    	return size;
    }//getSize method ends
    
    
    //auxiliary function for inorderTraversal and getLongest
    public void leftnode(TrieNode node, String s, ArrayList<String> arr)
    {
		if(node!=null)	{    			
    		leftnode(node.left, s+node.str, arr);
    		if(node.isKey == true)
    			arr.add(s+node.str);
    		leftnode(node.right, s+node.str, arr);
		}//if ends
		else {
			return;
		}//else ends
		
    }//leftnode method ends

    /**
     * <p>Performs an <i>inorder (symmetric) traversal</i> of the Binary Patricia Trie. Remember from lecture that inorder
     * traversal in tries is NOT sorted traversal, unless all the stored keys have the same length. This
     * is of course not required by your implementation, so you should make sure that in your tests you
     * are not expecting this method to return keys in lexicographic order. We put this method in the
     * interface because it helps us test your submission thoroughly and it helps you debug your code! </p>
     *
     * <p>We <b>neither require nor test </b> whether the {@link Iterator} returned by this method is fail-safe or fail-fast.
     * This means that you  do <b>not</b> need to test for thrown {@link java.util.ConcurrentModificationException}s and we do
     * <b>not</b> test your code for the possible occurrence of concurrent modifications.</p>
     *
     * <p>We also assume that the {@link Iterator} is <em>immutable</em>, i,e we do <b>not</b> test for the behavior
     * of {@link Iterator#remove()}. You can handle it any way you want for your own application, yet <b>we</b> will
     * <b>not</b> test for it.</p>
     *
     * @return An {@link Iterator} over the {@link String} keys stored in the trie, exposing the elements in <i>symmetric
     * order</i>.
     */
    //call on left process you need on 
    public Iterator<String> inorderTraversal() {
       // throw new UnimplementedMethodException(); // ERASE THIS LINE AFTER YOU IMPLEMENT THE METHOD!
    	ArrayList<String> arry = new ArrayList<String>();  
	    String s = "";
	    	
		leftnode(this.root, s, arry); 
		return arry.iterator();    	
    }//inorderTraversal method ends
    
  
    
    public String longest(ArrayList<String> list) {
    	ArrayList<String> array = new ArrayList<String>();  
 	   	String s = "", result = "";	 	   	
 	   	
 	    leftnode(this.root, s, array);
 	    int max =array.get(0).length();
 	  
 	    for(int i = 0; i < array.size(); i++) {
 	    	if(max <= array.get(i).length()) {
 	    		max = array.get(i).length();
 	    		result = array.get(i);
 	    	}//if ends
 	    }//for loop ends
 	   
 	   return result;
    }//longest method ends
    
    /**
     * Finds the longest {@link String} stored in the Binary Patricia Trie.
     * @return <p>The longest {@link String} stored in this. If the trie is empty, the empty string &quot;&quot; should be
     * returned. Careful: the empty string &quot;&quot;is <b>not</b> the same string as &quot; &quot;; the latter is a string
     * consisting of a single <b>space character</b>! It is also <b>not the same as the</b> null <b>reference</b>!</p>
     *
     * <p>Ties should be broken in terms of <b>value</b> of the bit string. For example, if our trie contained
     * only the binary strings 01 and 11, <b>11</b> would be the longest string. If our trie contained
     * only 001 and 010, <b>010</b> would be the longest string.</p>
     */
    public String getLongest() {
        //throw new UnimplementedMethodException(); // ERASE THIS LINE AFTER YOU IMPLEMENT THE METHOD!
    	String result = null;
    	ArrayList<String> array = new ArrayList<String>();
    	
    	if(this.root == null) {
    		result = "";
    	}//if ends
    	else {
    		result = longest(array);
    	}//else ends
    	
    	return result; 
    }//getLongest method ends

    /**
     * Makes sure that your trie doesn't have splitter nodes with a single child. In a Patricia trie, those nodes should
     * be pruned.
     * @return {@code true} iff all nodes in the trie either denote stored strings or split into two subtrees, {@code false} otherwise.
     */
    public boolean isJunkFree(){
        return isEmpty() || (isJunkFree(root.left) && isJunkFree(root.right));
    }//isJunkFree method ends

    private boolean isJunkFree(TrieNode n){
        if(n == null){   // Null subtrees trivially junk-free
            return true;
        }
        if(!n.isKey){   // Non-key nodes need to be strict splitter nodes
            return ( (n.left != null) && (n.right != null) && isJunkFree(n.left) && isJunkFree(n.right) );
        } else {
            return ( isJunkFree(n.left) && isJunkFree(n.right) ); // But key-containing nodes need not.
        }
    }
}
